# PriceLens — Sweet Shop Edition (Hybrid AI + Dual OV5640 ESP32-S3 Scale Camera)

PriceLens is a commercial-grade, responsive counter price-display system tailored for **sweet shops and retail counters**, combining:

1. **Live Visual Scanner (`Scanner` tab):** On-device MobileNet v2 (strict 224×224 viewfinder center-crop + dual-scale matching + 4.5% margin check) paired with optional Tier 2 Cloud Vision (`gemini-3.5-flash-lite`, `google/gemma-4-31b-it:free`, or `claude-haiku-5-5`).
2. **Sweet Shop Weighing Scale Camera (`Scale Cam` tab):** Connects your custom **Dual OV5640 + ESP32-S3-WROOM-1-N16R8** Wi-Fi camera:
   - **CAM1 (Front · GPIO 1):** Captures the sweet on the weighing pan and identifies it.
   - **CAM2 (Back · GPIO 2):** Captures the digital weighing scale's 7-segment display and reads the exact weight via AI OCR.
   - **Instant Price Calculation:** Multiplies confirmed weight × stored rate (`per kg`, `per 500g`, `per 250g`) and displays the arm's-length total price (with 1-tap sweet switch & manual gram fine-tune).
3. **Firebase Backend & Database:** Cloud Firestore real-time sync with offline IndexedDB persistence (`pricelens-a65bb` pre-wired in `.env` and `.firebaserc`).
4. **Hardware Bundle Included (`hardware/`):**
   - `hardware/esp32_dual_cam/esp32_dual_cam.ino` — Locked GPIO pinout, 8MB OPI PSRAM Base64 encoding, auto-reconnect.
   - `hardware/relay-server/` — Node.js Express + `ws` Cloud Relay (`server.js`, `Dockerfile`, `render.yaml`) ready for Render, Railway, or Fly.io.

---

## Quick Deployment Checklist

### 1. Deploy Web App to Vercel
- Push the unzipped project to GitHub and deploy on Vercel.
- Ensure your **Firebase `VITE_FIREBASE_*`** variables and **`GEMINI_API_KEY`** (Secret, no `VITE_`) are set in **Vercel → Settings → Environment Variables**, then redeploy.

### 2. Deploy the Dual-Camera WebSocket Relay (`hardware/relay-server/`)
- Deploy `hardware/relay-server/` to Render (using `render.yaml`), Railway, or Fly.io with `DEVICE_TOKEN` and `APP_TOKEN`.
- Paste `wss://YOUR_RELAY_URL/app` and `APP_TOKEN` into **PriceLens → Settings → Dual OV5640 Wi-Fi Scale Camera**.

### 3. Flash the ESP32-S3 (`hardware/esp32_dual_cam/esp32_dual_cam.ino`)
- Install **esp32** board package + **ArduinoWebsockets** (Gil Maimon) in Arduino IDE.
- Select **Board:** `ESP32S3 Dev Module`, **Flash Size:** `16MB (128Mb)`, **PSRAM:** **`OPI PSRAM`**.
- Update `WIFI_SSID`, `WIFI_PASSWORD`, and `RELAY_WS_URL` (`wss://YOUR_RELAY_URL/esp?token=DEVICE_TOKEN`), then upload.
