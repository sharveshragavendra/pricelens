/*
 * ============================================================================
 * PriceLens — Dual OV5640 + ESP32-S3 Wi-Fi Camera Firmware
 * ============================================================================
 * Hardware: ESP32-S3-WROOM-1-N16R8 (16MB Flash, 8MB OPI PSRAM)
 * Sensors : 2x OV5640 (5MP) sharing one DVP bus, isolated via PWDN pins
 *           - CAM1 (Front): GPIO 1 (Active LOW = ON, HIGH = OFF)
 *           - CAM2 (Back) : GPIO 2 (Active LOW = ON, HIGH = OFF)
 *
 * Libraries Required (Install via Arduino Library Manager):
 *   1. ArduinoWebsockets by Gil Maimon (v0.5.3+)
 *   2. ESP32 Board Package by Espressif Systems (v2.0.14+ or v3.0.x)
 *
 * Arduino IDE Board Settings (CRITICAL):
 *   - Board            : ESP32S3 Dev Module
 *   - Flash Size       : 16MB (128Mb)
 *   - Partition Scheme : 16M Flash (3MB APP/9.9MB FATFS) or Default 4MB
 *   - PSRAM            : OPI PSRAM   <-- REQUIRED!
 *   - USB CDC On Boot  : Enabled (if using native USB serial)
 * ============================================================================
 */

#include <Arduino.h>
#include <WiFi.h>
#include <ArduinoWebsockets.h>
#include "esp_camera.h"
#include "mbedtls/base64.h"

using namespace websockets;

// ============================================================================
// 1. USER CONFIGURATION — Update before flashing
// ============================================================================
const char* WIFI_SSID        = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD    = "YOUR_WIFI_PASSWORD";

// Example: "wss://pricelens-cam-relay.onrender.com/esp?token=CHANGE_ME_DEVICE_TOKEN"
const char* RELAY_WS_URL     = "wss://YOUR_RELAY_URL/esp?token=DEVICE_TOKEN";

// Resolution: FRAMESIZE_HD (1280x720) for fast ~1s transfer, or FRAMESIZE_UXGA (1600x1200)
static const framesize_t CAPTURE_FRAME_SIZE = FRAMESIZE_HD;
static const int         CAPTURE_JPEG_QUALITY = 10; // 0-63 (lower = higher quality)

// ============================================================================
// 2. STRICT HARDWARE PIN MAPPING (DO NOT CHANGE)
// ============================================================================
#define PWDN_GPIO_NUM     -1  // Managed manually via CAM1_PWDN_PIN & CAM2_PWDN_PIN
#define RESET_GPIO_NUM    21  // Shared active-LOW hardware reset
#define XCLK_GPIO_NUM     15
#define SIOD_GPIO_NUM     4   // SDA
#define SIOC_GPIO_NUM     5   // SCL

#define Y9_GPIO_NUM       16  // D7
#define Y8_GPIO_NUM       17  // D6
#define Y7_GPIO_NUM       18  // D5
#define Y6_GPIO_NUM       12  // D4
#define Y5_GPIO_NUM       10  // D3
#define Y4_GPIO_NUM       8   // D2
#define Y3_GPIO_NUM       9   // D1
#define Y2_GPIO_NUM       11  // D0

#define VSYNC_GPIO_NUM    6
#define HREF_GPIO_NUM     7
#define PCLK_GPIO_NUM     13

// Camera Power-Down Switching Pins (Active LOW = ON, HIGH = OFF)
#define CAM1_PWDN_PIN     1   // Front Camera
#define CAM2_PWDN_PIN     2   // Back Camera

// ============================================================================
// 3. RUNTIME STATE
// ============================================================================
WebsocketsClient wsClient;
bool cameraInitialized = false;
bool captureInProgress = false;
unsigned long lastReconnectAttemptMs = 0;
unsigned long lastPingMs = 0;

static const unsigned long RECONNECT_INTERVAL_MS = 5000;
static const unsigned long PING_INTERVAL_MS      = 25000;

// ============================================================================
// 4. CAMERA HELPERS (Dual OV5640 Bus Switching + OPI PSRAM)
// ============================================================================
camera_config_t buildCameraConfig() {
  camera_config_t config;
  memset(&config, 0, sizeof(config));

  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer   = LEDC_TIMER_0;
  config.pin_d0       = Y2_GPIO_NUM;
  config.pin_d1       = Y3_GPIO_NUM;
  config.pin_d2       = Y4_GPIO_NUM;
  config.pin_d3       = Y5_GPIO_NUM;
  config.pin_d4       = Y6_GPIO_NUM;
  config.pin_d5       = Y7_GPIO_NUM;
  config.pin_d6       = Y8_GPIO_NUM;
  config.pin_d7       = Y9_GPIO_NUM;
  config.pin_xclk     = XCLK_GPIO_NUM;
  config.pin_pclk     = PCLK_GPIO_NUM;
  config.pin_vsync    = VSYNC_GPIO_NUM;
  config.pin_href     = HREF_GPIO_NUM;
  config.pin_sccb_sda = SIOD_GPIO_NUM;
  config.pin_sccb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn     = PWDN_GPIO_NUM;
  config.pin_reset    = RESET_GPIO_NUM;

  config.xclk_freq_hz = 20000000;
  config.pixel_format = PIXFORMAT_JPEG;
  config.frame_size   = CAPTURE_FRAME_SIZE;
  config.jpeg_quality = CAPTURE_JPEG_QUALITY;
  config.fb_count     = 1;
  config.fb_location  = CAMERA_FB_IN_PSRAM;
  config.grab_mode    = CAMERA_GRAB_LATEST;

  return config;
}

void powerOffBothCameras() {
  digitalWrite(CAM1_PWDN_PIN, HIGH);
  digitalWrite(CAM2_PWDN_PIN, HIGH);
}

/**
 * Selects a single OV5640 sensor (1 = Front, 2 = Back), initializes it in OPI PSRAM,
 * discards 2 warm-up frames for auto-exposure/white balance, and returns the real JPEG frame.
 * Caller MUST release the returned frame with esp_camera_fb_return(fb).
 */
camera_fb_t* captureCamera(int camId) {
  if (camId != 1 && camId != 2) {
    Serial.printf("[CAM] Invalid camId: %d\n", camId);
    return nullptr;
  }

  // 1. De-initialize previous camera instance if active
  if (cameraInitialized) {
    esp_camera_deinit();
    cameraInitialized = false;
    delay(30);
  }

  // 2. Isolate sensors: ONLY requested camera LOW (ON), the other HIGH (OFF)
  if (camId == 1) {
    digitalWrite(CAM2_PWDN_PIN, HIGH);
    digitalWrite(CAM1_PWDN_PIN, LOW);
    Serial.println("[CAM] Selected CAM1 (Front - GPIO 1 LOW)");
  } else {
    digitalWrite(CAM1_PWDN_PIN, HIGH);
    digitalWrite(CAM2_PWDN_PIN, LOW);
    Serial.println("[CAM] Selected CAM2 (Back - GPIO 2 LOW)");
  }

  // 3. Wait 100ms for sensor power rail & oscillator stabilization
  delay(100);

  // 4. Initialize OV5640 with OPI PSRAM frame buffer
  camera_config_t config = buildCameraConfig();
  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.printf("[CAM] esp_camera_init failed for CAM%d (0x%x)\n", camId, err);
    powerOffBothCameras();
    return nullptr;
  }
  cameraInitialized = true;

  // Apply clean baseline sensor tuning for OV5640
  sensor_t* sensor = esp_camera_sensor_get();
  if (sensor != nullptr) {
    sensor->set_whitebal(sensor, 1);
    sensor->set_awb_gain(sensor, 1);
    sensor->set_exposure_ctrl(sensor, 1);
    sensor->set_gain_ctrl(sensor, 1);
  }

  // 5. Capture and discard 2 warm-up frames so AE/AWB settles
  for (int i = 0; i < 2; i++) {
    camera_fb_t* warmup = esp_camera_fb_get();
    if (warmup != nullptr) {
      esp_camera_fb_return(warmup);
    }
    delay(80);
  }

  // 6. Capture the real JPEG frame
  camera_fb_t* fb = esp_camera_fb_get();
  if (fb == nullptr) {
    Serial.printf("[CAM] Failed to grab final frame from CAM%d\n", camId);
    return nullptr;
  }

  Serial.printf("[CAM] Captured CAM%d JPEG: %u bytes (%ux%u)\n",
                camId, (unsigned int)fb->len, fb->width, fb->height);
  return fb;
}

/**
 * Encodes a JPEG frame into Base64 inside OPI PSRAM and sends:
 *   {"type":"photo","cam":"front|back","data":"<base64_jpeg>"}
 */
bool sendPhotoOverWebSocket(const char* camLabel, camera_fb_t* fb) {
  if (fb == nullptr || fb->buf == nullptr || fb->len == 0) {
    return false;
  }

  // Compute exact Base64 output length
  size_t b64Required = 0;
  mbedtls_base64_encode(nullptr, 0, &b64Required, fb->buf, fb->len);

  char prefix[64];
  int prefixLen = snprintf(prefix, sizeof(prefix),
                           "{\"type\":\"photo\",\"cam\":\"%s\",\"data\":\"", camLabel);
  const char* suffix = "\"}";
  size_t suffixLen = strlen(suffix);

  size_t totalAlloc = (size_t)prefixLen + b64Required + suffixLen + 2;
  char* payloadBuf = (char*)ps_malloc(totalAlloc);
  if (payloadBuf == nullptr) {
    Serial.printf("[WS] ps_malloc failed (%u bytes). Ensure OPI PSRAM is enabled!\n",
                  (unsigned int)totalAlloc);
    return false;
  }

  memcpy(payloadBuf, prefix, prefixLen);

  size_t b64Written = 0;
  int rc = mbedtls_base64_encode(
      (unsigned char*)(payloadBuf + prefixLen),
      b64Required + 1,
      &b64Written,
      fb->buf,
      fb->len);

  if (rc != 0) {
    Serial.printf("[WS] Base64 encode failed (rc=%d)\n", rc);
    free(payloadBuf);
    return false;
  }

  memcpy(payloadBuf + prefixLen + b64Written, suffix, suffixLen);
  size_t finalLen = (size_t)prefixLen + b64Written + suffixLen;
  payloadBuf[finalLen] = '\0';

  bool sent = wsClient.send(payloadBuf, finalLen);
  free(payloadBuf);

  Serial.printf("[WS] Sent %s photo JSON (%u bytes): %s\n",
                camLabel, (unsigned int)finalLen, sent ? "OK" : "FAILED");
  return sent;
}

void handleDualCapture() {
  if (captureInProgress) {
    Serial.println("[CMD] Dual capture already in progress, ignoring duplicate.");
    return;
  }
  captureInProgress = true;

  wsClient.send("{\"type\":\"status\",\"msg\":\"capturing_front\"}");

  // --- Step 1: Capture & send CAM1 (Front) ---
  camera_fb_t* frontFb = captureCamera(1);
  if (frontFb != nullptr) {
    sendPhotoOverWebSocket("front", frontFb);
    esp_camera_fb_return(frontFb);
  } else {
    wsClient.send("{\"type\":\"error\",\"cam\":\"front\",\"msg\":\"Failed to capture front camera\"}");
  }

  wsClient.send("{\"type\":\"status\",\"msg\":\"capturing_back\"}");

  // --- Step 2: Immediately switch to CAM2 (Back) & send ---
  camera_fb_t* backFb = captureCamera(2);
  if (backFb != nullptr) {
    sendPhotoOverWebSocket("back", backFb);
    esp_camera_fb_return(backFb);
  } else {
    wsClient.send("{\"type\":\"error\",\"cam\":\"back\",\"msg\":\"Failed to capture back camera\"}");
  }

  // Power down cameras between captures to reduce heat and power draw
  if (cameraInitialized) {
    esp_camera_deinit();
    cameraInitialized = false;
  }
  powerOffBothCameras();

  // --- Step 3: Notify completion ---
  wsClient.send("{\"type\":\"status\",\"msg\":\"done\"}");
  captureInProgress = false;
}

// ============================================================================
// 5. WI-FI & SECURE WEBSOCKET CONNECTION MANAGEMENT
// ============================================================================
void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;

  Serial.printf("[WiFi] Connecting to %s", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false); // Keep low-latency WebSocket responsiveness
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && (millis() - start) < 15000) {
    delay(300);
    Serial.print(".");
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("\n[WiFi] Connected! IP: %s | RSSI: %d dBm\n",
                  WiFi.localIP().toString().c_str(), WiFi.RSSI());
  } else {
    Serial.println("\n[WiFi] Connection timed out, will retry...");
  }
}

void onWebSocketMessage(WebsocketsMessage message) {
  String payload = message.data();
  Serial.printf("[WS] Received: %s\n", payload.c_str());

  if (payload.indexOf("\"dual_capture\"") >= 0) {
    handleDualCapture();
  } else if (payload.indexOf("\"ping\"") >= 0) {
    wsClient.send("{\"type\":\"pong\"}");
  }
}

void onWebSocketEvent(WebsocketsEvent event, String data) {
  if (event == WebsocketsEvent::ConnectionOpened) {
    Serial.println("[WS] Connected to cloud relay!");
    wsClient.send("{\"type\":\"status\",\"msg\":\"ready\"}");
  } else if (event == WebsocketsEvent::ConnectionClosed) {
    Serial.printf("[WS] Connection closed (%s)\n", data.c_str());
  } else if (event == WebsocketsEvent::GotPing) {
    wsClient.pong();
  }
}

void connectWebSocket() {
  if (WiFi.status() != WL_CONNECTED) return;

  Serial.printf("[WS] Connecting to %s\n", RELAY_WS_URL);
  // Accepts TLS certificates for Render/Railway/Fly.io out of the box.
  // For pinned production TLS, replace with wsClient.setCACert(ROOT_CA_PEM).
  wsClient.setInsecure();
  wsClient.onMessage(onWebSocketMessage);
  wsClient.onEvent(onWebSocketEvent);

  bool ok = wsClient.connect(RELAY_WS_URL);
  if (!ok) {
    Serial.println("[WS] Connect attempt failed, will retry...");
  }
}

// ============================================================================
// 6. ARDUINO SETUP & LOOP
// ============================================================================
void setup() {
  Serial.begin(115200);
  delay(500);
  Serial.println("\n=== PriceLens Dual OV5640 ESP32-S3 Boot ===");

  if (!psramFound()) {
    Serial.println("[ERROR] PSRAM NOT DETECTED! Enable 'OPI PSRAM' in Arduino IDE -> Tools.");
  } else {
    Serial.printf("[MEM] OPI PSRAM Ready: %u bytes free\n", (unsigned int)ESP.getFreePsram());
  }

  // Configure camera switching pins (default both OFF = HIGH)
  pinMode(CAM1_PWDN_PIN, OUTPUT);
  pinMode(CAM2_PWDN_PIN, OUTPUT);
  powerOffBothCameras();

  connectWiFi();
  connectWebSocket();
}

void loop() {
  unsigned long now = millis();

  // Auto-reconnect Wi-Fi if dropped
  if (WiFi.status() != WL_CONNECTED) {
    if (now - lastReconnectAttemptMs >= RECONNECT_INTERVAL_MS) {
      lastReconnectAttemptMs = now;
      connectWiFi();
    }
    delay(50);
    return;
  }

  // Poll active socket or auto-reconnect WebSocket
  if (wsClient.available()) {
    wsClient.poll();

    // Periodic keepalive ping so cloud proxies never idle-close the socket
    if (now - lastPingMs >= PING_INTERVAL_MS) {
      lastPingMs = now;
      wsClient.ping();
    }
  } else {
    if (now - lastReconnectAttemptMs >= RECONNECT_INTERVAL_MS) {
      lastReconnectAttemptMs = now;
      connectWebSocket();
    }
  }

  delay(10);
}
