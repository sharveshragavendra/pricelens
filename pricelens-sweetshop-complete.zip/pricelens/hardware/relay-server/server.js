require('dotenv').config();

const http = require('http');
const express = require('express');
const { WebSocketServer, WebSocket } = require('ws');

const PORT = Number(process.env.PORT || 8080);
const DEVICE_TOKEN = process.env.DEVICE_TOKEN || 'CHANGE_ME_DEVICE_TOKEN';
const APP_TOKEN = process.env.APP_TOKEN || 'CHANGE_ME_APP_TOKEN';
const MAX_PAYLOAD_BYTES = 5 * 1024 * 1024; // 5MB max WebSocket frame payload

const app = express();
app.disable('x-powered-by');

// Lightweight CORS + JSON health endpoint for Render / Railway / Fly.io
app.get('/health', (_req, res) => {
  res.status(200).json({
    ok: true,
    espConnected: Boolean(espSocket && espSocket.readyState === WebSocket.OPEN),
    appClients: appClients.size,
    uptimeSec: Math.round(process.uptime()),
  });
});

app.get('/', (_req, res) => {
  res.status(200).send('PriceLens Dual-Camera WebSocket Relay is running.');
});

const server = http.createServer(app);

// Use noServer mode so we can cleanly route & authenticate /esp and /app paths
const wss = new WebSocketServer({
  noServer: true,
  maxPayload: MAX_PAYLOAD_BYTES,
});

/** @type {WebSocket | null} */
let espSocket = null;
/** @type {Set<WebSocket>} */
const appClients = new Set();

function broadcastToApps(payloadString) {
  for (const client of appClients) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(payloadString);
    }
  }
}

function sendEspStatusToApps() {
  const connected = Boolean(espSocket && espSocket.readyState === WebSocket.OPEN);
  broadcastToApps(JSON.stringify({ type: 'esp_status', connected }));
}

server.on('upgrade', (request, socket, head) => {
  try {
    const reqUrl = new URL(request.url || '/', `http://${request.headers.host || 'localhost'}`);
    const pathname = reqUrl.pathname;
    const token = reqUrl.searchParams.get('token') || '';

    if (pathname === '/esp') {
      if (token !== DEVICE_TOKEN) {
        socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
        socket.destroy();
        return;
      }
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request, 'esp');
      });
      return;
    }

    if (pathname === '/app') {
      if (token !== APP_TOKEN) {
        socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
        socket.destroy();
        return;
      }
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request, 'app');
      });
      return;
    }

    socket.write('HTTP/1.1 404 Not Found\r\n\r\n');
    socket.destroy();
  } catch {
    socket.write('HTTP/1.1 400 Bad Request\r\n\r\n');
    socket.destroy();
  }
});

wss.on('connection', (ws, _request, role) => {
  ws.isAlive = true;
  ws.on('pong', () => {
    ws.isAlive = true;
  });

  if (role === 'esp') {
    console.log('[RELAY] ESP32-S3 connected.');
    if (espSocket && espSocket !== ws && espSocket.readyState === WebSocket.OPEN) {
      console.log('[RELAY] Closing previous stale ESP32-S3 connection.');
      espSocket.terminate();
    }
    espSocket = ws;
    sendEspStatusToApps();

    ws.on('message', (rawData) => {
      const text = typeof rawData === 'string' ? rawData : rawData.toString('utf8');
      // Forward photo & status JSON from ESP32 to all connected app clients
      broadcastToApps(text);
    });

    ws.on('close', () => {
      console.log('[RELAY] ESP32-S3 disconnected.');
      if (espSocket === ws) {
        espSocket = null;
        sendEspStatusToApps();
      }
    });

    ws.on('error', (err) => {
      console.error('[RELAY] ESP32 socket error:', err.message);
    });
    return;
  }

  // role === 'app'
  appClients.add(ws);
  console.log(`[RELAY] App client connected (total: ${appClients.size}).`);

  // Immediately report whether the ESP32-S3 is currently online
  ws.send(
    JSON.stringify({
      type: 'esp_status',
      connected: Boolean(espSocket && espSocket.readyState === WebSocket.OPEN),
    })
  );

  ws.on('message', (rawData) => {
    const text = typeof rawData === 'string' ? rawData : rawData.toString('utf8');

    // Validate JSON command before forwarding to ESP32
    try {
      const parsed = JSON.parse(text);
      if (!espSocket || espSocket.readyState !== WebSocket.OPEN) {
        ws.send(
          JSON.stringify({
            type: 'error',
            msg: 'ESP32-S3 camera is currently offline.',
          })
        );
        return;
      }
      espSocket.send(JSON.stringify(parsed));
    } catch {
      ws.send(JSON.stringify({ type: 'error', msg: 'Invalid JSON command.' }));
    }
  });

  ws.on('close', () => {
    appClients.delete(ws);
    console.log(`[RELAY] App client disconnected (total: ${appClients.size}).`);
  });

  ws.on('error', (err) => {
    console.error('[RELAY] App socket error:', err.message);
  });
});

// Heartbeat interval (30s) to detect dead mobile/ESP32 connections cleanly
const heartbeat = setInterval(() => {
  for (const client of wss.clients) {
    if (client.isAlive === false) {
      client.terminate();
      continue;
    }
    client.isAlive = false;
    client.ping();
  }
}, 30000);

wss.on('close', () => {
  clearInterval(heartbeat);
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`[RELAY] Dual-Camera WebSocket Relay listening on port ${PORT}`);
  console.log(`[RELAY] Health check: http://0.0.0.0:${PORT}/health`);
});
