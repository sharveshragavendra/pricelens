export type ActiveTab = 'scanner' | 'scalecam' | 'catalog' | 'settings';

export type ScanSpeedMs = 300 | 500 | 1000;

export type ThemeMode = 'light' | 'dark';

export type CloudAiProvider = 'openrouter' | 'gemini' | 'claude';

export type HybridMode = 'off' | 'manual' | 'auto';

export type ScaleCameraSource = 'mobile' | 'esp32';

export interface ProductVariant {
  id: string;
  label: string;
  price: number;
}

export interface ProductAngle {
  id: string;
  label: string;
  thumbnail: string;
  storagePath?: string;
  embedding: number[];
}

export interface Product {
  id: string;
  name: string;
  basePrice: number;
  unit: string;
  category: string;
  variants: ProductVariant[];
  angles: ProductAngle[];
  createdAt: number;
  updatedAt: number;
}

export interface AppSettings {
  currencySymbol: string;
  confidenceThreshold: number;
  scanIntervalMs: ScanSpeedMs;
  theme: ThemeMode;
  hybridMode: HybridMode;
  cloudAiProvider: CloudAiProvider;
  // Scale Cam source: phone front+back dual camera OR external ESP32-S3 Wi-Fi camera
  scaleCameraSource: ScaleCameraSource;
  espRelayUrl: string;
  espAppToken: string;
  scaleDefaultUnit: 'kg' | 'g';
}

export const DEFAULT_SETTINGS: AppSettings = {
  currencySymbol: '₹',
  confidenceThreshold: 0.78,
  scanIntervalMs: 500,
  theme: 'dark',
  hybridMode: 'manual',
  cloudAiProvider: 'gemini',
  scaleCameraSource: 'mobile',
  espRelayUrl: '',
  espAppToken: '',
  scaleDefaultUnit: 'kg',
};

export interface ProductMatch {
  product: Product;
  score: number;
  bestAngleId: string;
  source?: 'local' | 'cloud';
  matchedVariantId?: string | null;
  cloudModel?: string;
  cloudReason?: string;
}

export interface ScaleWeightReading {
  weightKg: number | null;
  rawDisplayText: string;
  detectedUnit: 'kg' | 'g' | 'unknown';
  confidence: number;
  reason: string;
}

export interface FrameQualityResult {
  status: 'good' | 'too_dark' | 'hold_steady';
  label: string | null;
  brightness: number;
  motion: number;
}

export interface CloudVisionStatus {
  available: boolean;
  openrouterConfigured: boolean;
  geminiConfigured: boolean;
  claudeConfigured: boolean;
  openrouterModel: string;
  geminiModel: string;
  claudeModel: string;
}

export interface CatalogBackupPayload {
  app: 'PriceLens';
  version: 1;
  exportedAt: string;
  settings?: Partial<AppSettings>;
  products: Product[];
}

export interface AuthState {
  mode: 'firebase' | 'local';
  ready: boolean;
  uid: string | null;
  email: string | null;
  isAnonymous: boolean;
  error: string | null;
}

export const ANGLE_SUGGESTIONS = [
  'Front',
  'Side',
  'Top',
  'Back',
  'Close-Up',
] as const;

export const UNCERTAIN_MIN_THRESHOLD = 0.60;

export const MIN_TOP_MARGIN = 0.045;
