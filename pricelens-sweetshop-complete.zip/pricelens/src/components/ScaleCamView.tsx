import { useCallback, useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  Camera,
  CheckCircle2,
  Cpu,
  Download,
  Edit3,
  Layers,
  Loader2,
  PictureInPicture2,
  Plus,
  RefreshCw,
  Scale,
  Settings as SettingsIcon,
  Smartphone,
  Sparkles,
  SwitchCamera,
  Upload,
  Wand2,
  Wifi,
  WifiOff,
} from 'lucide-react';
import type { ModelState } from '../hooks/useModel';
import {
  analyzeSweetAndScaleWithCloudAI,
  readScaleWeightWithCloudAI,
} from '../services/cloudVision';
import {
  captureVideoFrameAsDataUrl,
  compressImageFile,
  formatPrice,
  loadImageElement,
} from '../services/imageUtils';
import {
  extractNormalizedEmbedding,
  matchProductsMultiCrop,
} from '../services/visionEngine';
import {
  calculateWeighedPrice,
  formatWeightDisplay,
} from '../services/weightUtils';
import type {
  AppSettings,
  CloudVisionStatus,
  Product,
  ProductMatch,
  ScaleCameraSource,
  ScaleWeightReading,
} from '../types';

interface ScaleCamViewProps {
  products: Product[];
  settings: AppSettings;
  modelState: ModelState;
  cloudStatus: CloudVisionStatus;
  onUpdateSettings: (next: AppSettings) => Promise<void>;
  onOpenSettings: () => void;
  onAddFirstProduct: () => void;
}

interface CapturedPhoto {
  dataUrl: string;
  timestamp: string;
}

type PipelineStage =
  | 'idle'
  | 'capturing_front'
  | 'capturing_back'
  | 'analyzing';

function nowTimestamp(): string {
  return new Date().toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
}

function waitMs(ms: number): Promise<void> {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

export function ScaleCamView({
  products,
  settings,
  modelState,
  cloudStatus,
  onUpdateSettings,
  onOpenSettings,
  onAddFirstProduct,
}: ScaleCamViewProps) {
  const cameraSource: ScaleCameraSource = settings.scaleCameraSource || 'mobile';

  // External ESP32 WebSocket refs
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimerRef = useRef<number | null>(null);

  // Mobile Phone Dual Camera refs
  const phoneVideoRef = useRef<HTMLVideoElement | null>(null);
  const phoneStreamRef = useRef<MediaStream | null>(null);

  // Captured photos & matching refs
  const frontPhotoRef = useRef<CapturedPhoto | null>(null);
  const backPhotoRef = useRef<CapturedPhoto | null>(null);
  const localMatchRef = useRef<{
    locked: ProductMatch | null;
    ranked: ProductMatch[];
  }>({ locked: null, ranked: [] });

  const testFrontInputRef = useRef<HTMLInputElement | null>(null);
  const testBackInputRef = useRef<HTMLInputElement | null>(null);

  // Connection & capture state
  const [wsConnected, setWsConnected] = useState(false);
  const [espConnected, setEspConnected] = useState(false);
  const [phoneFacing, setPhoneFacing] = useState<'environment' | 'user'>('environment');
  const [phoneCamReady, setPhoneCamReady] = useState(false);
  const [phoneCamStarting, setPhoneCamStarting] = useState(false);

  const [stage, setStage] = useState<PipelineStage>('idle');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const [frontPhoto, setFrontPhoto] = useState<CapturedPhoto | null>(null);
  const [backPhoto, setBackPhoto] = useState<CapturedPhoto | null>(null);

  const [selectedMatch, setSelectedMatch] = useState<ProductMatch | null>(null);
  const [candidateMatches, setCandidateMatches] = useState<ProductMatch[]>([]);
  const [weightReading, setWeightReading] = useState<ScaleWeightReading | null>(null);
  const [manualWeightGrams, setManualWeightGrams] = useState<string>('');
  const [editingWeight, setEditingWeight] = useState(false);

  const [mobileLayout, setMobileLayout] = useState<'stacked' | 'pip'>('stacked');
  const [pipPrimary, setPipPrimary] = useState<'front' | 'back'>('front');
  const [showTestUpload, setShowTestUpload] = useState(false);

  const relayUrl =
    settings.espRelayUrl.trim() ||
    (import.meta.env.VITE_DUAL_CAM_RELAY_URL as string | undefined) ||
    '';
  const appToken =
    settings.espAppToken.trim() ||
    (import.meta.env.VITE_DUAL_CAM_APP_TOKEN as string | undefined) ||
    '';
  const isRelayConfigured = Boolean(relayUrl && !relayUrl.includes('YOUR_RELAY_URL'));

  const providerConfigured =
    settings.cloudAiProvider === 'openrouter'
      ? cloudStatus.openrouterConfigured
      : settings.cloudAiProvider === 'claude'
        ? cloudStatus.claudeConfigured
        : cloudStatus.geminiConfigured;

  const stopPhoneCamera = useCallback(() => {
    if (phoneStreamRef.current) {
      phoneStreamRef.current.getTracks().forEach((t) => t.stop());
      phoneStreamRef.current = null;
    }
    if (phoneVideoRef.current) {
      phoneVideoRef.current.srcObject = null;
    }
    setPhoneCamReady(false);
  }, []);

  const startPhoneCamera = useCallback(
    async (facing: 'environment' | 'user'): Promise<boolean> => {
      stopPhoneCamera();
      if (!navigator.mediaDevices?.getUserMedia) {
        setErrorMsg('Camera access requires HTTPS (or localhost) in a modern browser.');
        return false;
      }

      setPhoneCamStarting(true);
      setErrorMsg(null);
      try {
        let stream: MediaStream;
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            audio: false,
            video: {
              facingMode: { exact: facing },
              width: { ideal: 1280 },
              height: { ideal: 720 },
            },
          });
        } catch {
          // Graceful fallback for single-lens desktops or browsers without exact facingMode
          stream = await navigator.mediaDevices.getUserMedia({
            audio: false,
            video: {
              facingMode: { ideal: facing },
              width: { ideal: 1280 },
              height: { ideal: 720 },
            },
          });
        }

        phoneStreamRef.current = stream;
        setPhoneFacing(facing);

        if (phoneVideoRef.current) {
          phoneVideoRef.current.srcObject = stream;
          phoneVideoRef.current.muted = true;
          phoneVideoRef.current.playsInline = true;
          await phoneVideoRef.current.play().catch(() => undefined);
        }

        setPhoneCamReady(true);
        setPhoneCamStarting(false);
        return true;
      } catch (err) {
        setPhoneCamStarting(false);
        setPhoneCamReady(false);
        setErrorMsg(
          err instanceof Error
            ? `Unable to open ${facing === 'environment' ? 'back' : 'front'} camera: ${err.message}`
            : 'Camera permission denied or camera unavailable.'
        );
        return false;
      }
    },
    [stopPhoneCamera]
  );

  // Manage Phone Camera lifecycle when 'mobile' mode is active
  useEffect(() => {
    if (cameraSource !== 'mobile') {
      stopPhoneCamera();
      return;
    }
    void startPhoneCamera('environment');
    return () => {
      stopPhoneCamera();
    };
  }, [cameraSource, startPhoneCamera, stopPhoneCamera]);

  // Step A: Run local Tier 1 MobileNet matching on Sweet photo
  const runLocalSweetMatch = useCallback(
    async (dataUrl: string) => {
      if (!modelState.ready || products.length === 0) {
        localMatchRef.current = { locked: null, ranked: [] };
        return;
      }
      try {
        const img = await loadImageElement(dataUrl);
        const emb = extractNormalizedEmbedding(img);
        const { ranked, hasClearLead } = matchProductsMultiCrop([emb], products);
        const top = ranked[0] ?? null;
        const locked =
          top && top.score >= settings.confidenceThreshold && hasClearLead
            ? top
            : null;
        localMatchRef.current = { locked, ranked };
        setCandidateMatches(ranked.slice(0, 3));
        if (locked) {
          setSelectedMatch(locked);
        }
      } catch {
        localMatchRef.current = { locked: null, ranked: [] };
      }
    },
    [modelState.ready, products, settings.confidenceThreshold]
  );

  // Step B: Analyze both captured photos (Sweet + Scale Display)
  const runDualAnalysis = useCallback(
    async (sweetDataUrl: string, scaleDataUrl: string) => {
      setStage('analyzing');
      setErrorMsg(null);

      try {
        await runLocalSweetMatch(sweetDataUrl);
        const { locked, ranked } = localMatchRef.current;

        if (!providerConfigured) {
          if (locked) {
            setSelectedMatch(locked);
          } else if (ranked[0]) {
            setSelectedMatch(ranked[0]);
          }
          setWeightReading({
            weightKg: null,
            rawDisplayText: '',
            detectedUnit: 'unknown',
            confidence: 0,
            reason:
              'Add GEMINI_API_KEY in Vercel for automatic scale display OCR, or enter grams manually.',
          });
          setEditingWeight(true);
          return;
        }

        if (locked) {
          const ocr = await readScaleWeightWithCloudAI({
            scaleImageBase64: scaleDataUrl,
            provider: settings.cloudAiProvider,
            scaleDefaultUnit: settings.scaleDefaultUnit,
          });
          setSelectedMatch(locked);
          setWeightReading({
            weightKg: ocr.weightKg,
            rawDisplayText: ocr.rawDisplayText,
            detectedUnit: ocr.detectedUnit,
            confidence: ocr.confidence,
            reason: ocr.reason,
          });
          if (ocr.weightKg) {
            setManualWeightGrams(String(Math.round(ocr.weightKg * 1000)));
            setEditingWeight(false);
          } else {
            setEditingWeight(true);
          }
          return;
        }

        const shortlist =
          ranked.length > 0
            ? ranked.slice(0, 10).map((m) => m.product)
            : products.slice(0, 10);

        const combined = await analyzeSweetAndScaleWithCloudAI({
          productImageBase64: sweetDataUrl,
          scaleImageBase64: scaleDataUrl,
          provider: settings.cloudAiProvider,
          scaleDefaultUnit: settings.scaleDefaultUnit,
          candidates: shortlist,
        });

        if (combined.matchedProductId) {
          const prod = products.find((p) => p.id === combined.matchedProductId);
          if (prod) {
            setSelectedMatch({
              product: prod,
              score: Math.max(combined.productConfidence, 0.85),
              bestAngleId: prod.angles[0]?.id ?? 'cloud',
              source: 'cloud',
              matchedVariantId: combined.matchedVariantId,
              cloudModel: combined.model,
              cloudReason: combined.productReason,
            });
          }
        } else if (ranked[0]) {
          setSelectedMatch(ranked[0]);
        }

        setWeightReading({
          weightKg: combined.weightKg,
          rawDisplayText: combined.rawDisplayText,
          detectedUnit: combined.detectedUnit,
          confidence: combined.weightConfidence,
          reason: combined.weightReason,
        });

        if (combined.weightKg) {
          setManualWeightGrams(String(Math.round(combined.weightKg * 1000)));
          setEditingWeight(false);
        } else {
          setEditingWeight(true);
        }
      } catch (err) {
        setErrorMsg(
          err instanceof Error
            ? err.message
            : 'Unable to analyze sweet and scale images.'
        );
      } finally {
        setStage('idle');
      }
    },
    [
      products,
      providerConfigured,
      runLocalSweetMatch,
      settings.cloudAiProvider,
      settings.scaleDefaultUnit,
    ]
  );

  // Connect WebSocket ONLY when 'esp32' external camera source is selected
  const connectWebSocket = useCallback(() => {
    if (cameraSource !== 'esp32' || !isRelayConfigured) return;
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) return;

    if (reconnectTimerRef.current) {
      window.clearTimeout(reconnectTimerRef.current);
      reconnectTimerRef.current = null;
    }

    const cleanBase = relayUrl.replace(/\/+$/, '');
    const separator = cleanBase.includes('?') ? '&' : '?';
    const fullUrl = `${cleanBase}${separator}token=${encodeURIComponent(appToken)}`;

    try {
      const socket = new WebSocket(fullUrl);
      wsRef.current = socket;

      socket.onopen = () => {
        setWsConnected(true);
        setErrorMsg(null);
      };

      socket.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data as string) as {
            type?: string;
            connected?: boolean;
            cam?: string;
            data?: string;
            msg?: string;
          };

          if (msg.type === 'esp_status') {
            setEspConnected(Boolean(msg.connected));
            if (!msg.connected) setStage('idle');
            return;
          }

          if (msg.type === 'photo' && msg.data) {
            const dataUrl = msg.data.startsWith('data:image/')
              ? msg.data
              : `data:image/jpeg;base64,${msg.data}`;
            const record: CapturedPhoto = { dataUrl, timestamp: nowTimestamp() };

            if (msg.cam === 'front') {
              frontPhotoRef.current = record;
              setFrontPhoto(record);
              setStage('capturing_back');
              void runLocalSweetMatch(dataUrl);
            } else if (msg.cam === 'back') {
              backPhotoRef.current = record;
              setBackPhoto(record);
            }
            return;
          }

          if (msg.type === 'status') {
            if (msg.msg === 'capturing_front') setStage('capturing_front');
            else if (msg.msg === 'capturing_back') setStage('capturing_back');
            else if (msg.msg === 'done') {
              if (frontPhotoRef.current && backPhotoRef.current) {
                void runDualAnalysis(
                  frontPhotoRef.current.dataUrl,
                  backPhotoRef.current.dataUrl
                );
              } else {
                setStage('idle');
              }
            }
            return;
          }

          if (msg.type === 'error') {
            setErrorMsg(msg.msg || 'ESP32 camera reported an error.');
            setStage('idle');
          }
        } catch {
          // Ignore malformed payloads
        }
      };

      socket.onclose = () => {
        setWsConnected(false);
        setEspConnected(false);
        reconnectTimerRef.current = window.setTimeout(connectWebSocket, 3500);
      };

      socket.onerror = () => {
        setErrorMsg('Unable to reach Wi-Fi Camera Relay. Retrying...');
      };
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Invalid Relay WebSocket URL.');
    }
  }, [appToken, cameraSource, isRelayConfigured, relayUrl, runDualAnalysis, runLocalSweetMatch]);

  useEffect(() => {
    if (cameraSource !== 'esp32') {
      if (reconnectTimerRef.current) window.clearTimeout(reconnectTimerRef.current);
      if (wsRef.current) {
        wsRef.current.onclose = null;
        wsRef.current.close();
        wsRef.current = null;
      }
      setWsConnected(false);
      setEspConnected(false);
      return;
    }

    connectWebSocket();
    return () => {
      if (reconnectTimerRef.current) window.clearTimeout(reconnectTimerRef.current);
      if (wsRef.current) {
        wsRef.current.onclose = null;
        wsRef.current.close();
        wsRef.current = null;
      }
    };
  }, [cameraSource, connectWebSocket]);

  // --- PHONE DUAL CAM ACTIONS ---
  // Auto Dual Capture: Rear Cam (Sweet) -> flip to Front Cam (Scale LCD) -> Analyze & Price
  const handlePhoneAutoDualCapture = async () => {
    if (products.length === 0) return;
    setErrorMsg(null);
    setStage('capturing_front');

    try {
      // 1. Ensure Rear camera is active and snap the sweet
      if (phoneFacing !== 'environment' || !phoneCamReady) {
        const ok = await startPhoneCamera('environment');
        if (!ok) {
          setStage('idle');
          return;
        }
        await waitMs(700);
      }

      if (!phoneVideoRef.current) throw new Error('Phone camera stream unavailable.');
      const sweetUrl = captureVideoFrameAsDataUrl(phoneVideoRef.current, 640, 0.85, 0.85);
      const sweetRecord: CapturedPhoto = { dataUrl: sweetUrl, timestamp: nowTimestamp() };
      frontPhotoRef.current = sweetRecord;
      setFrontPhoto(sweetRecord);
      void runLocalSweetMatch(sweetUrl);

      // 2. Switch cleanly to Front camera and snap the weighing scale LCD
      setStage('capturing_back');
      const frontOk = await startPhoneCamera('user');
      if (!frontOk || !phoneVideoRef.current) {
        setStage('idle');
        return;
      }
      await waitMs(900); // Allow front lens AE/AWB to settle on LED/LCD digits

      const scaleUrl = captureVideoFrameAsDataUrl(phoneVideoRef.current, 640, 0.88, 0.92);
      const scaleRecord: CapturedPhoto = { dataUrl: scaleUrl, timestamp: nowTimestamp() };
      backPhotoRef.current = scaleRecord;
      setBackPhoto(scaleRecord);

      // Return to Rear camera ready for the next sweet
      void startPhoneCamera('environment');

      // 3. Identify sweet + read scale LCD + calculate price
      await runDualAnalysis(sweetUrl, scaleUrl);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Phone dual capture failed.');
      setStage('idle');
    }
  };

  // Manual 2-step Phone Capture (great when holding the phone by hand)
  const handlePhoneSnapSingle = async (target: 'sweet' | 'scale') => {
    if (!phoneVideoRef.current || !phoneCamReady) return;
    const dataUrl = captureVideoFrameAsDataUrl(phoneVideoRef.current, 640, 0.86, 0.88);
    const record: CapturedPhoto = { dataUrl, timestamp: nowTimestamp() };

    if (target === 'sweet') {
      frontPhotoRef.current = record;
      setFrontPhoto(record);
      void runLocalSweetMatch(dataUrl);
      // Conveniently flip to Front camera for the scale display shot
      if (phoneFacing === 'environment') {
        void startPhoneCamera('user');
      }
    } else {
      backPhotoRef.current = record;
      setBackPhoto(record);
      if (frontPhotoRef.current) {
        await runDualAnalysis(frontPhotoRef.current.dataUrl, dataUrl);
      }
    }
  };

  // --- EXTERNAL ESP32 ACTION ---
  const triggerEspDualCapture = () => {
    const socket = wsRef.current;
    if (!socket || socket.readyState !== WebSocket.OPEN) {
      setErrorMsg('Relay is disconnected. Reconnecting...');
      connectWebSocket();
      return;
    }
    if (!espConnected) {
      setErrorMsg('ESP32-S3 camera is offline. Check device power and Wi-Fi.');
      return;
    }
    setErrorMsg(null);
    setStage('capturing_front');
    frontPhotoRef.current = null;
    backPhotoRef.current = null;
    socket.send(JSON.stringify({ cmd: 'dual_capture' }));
  };

  const handleLocalTestUpload = async (
    cam: 'front' | 'back',
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    const dataUrl = await compressImageFile(file, 640, 0.85);
    const record: CapturedPhoto = { dataUrl, timestamp: nowTimestamp() };
    if (cam === 'front') {
      frontPhotoRef.current = record;
      setFrontPhoto(record);
      void runLocalSweetMatch(dataUrl);
    } else {
      backPhotoRef.current = record;
      setBackPhoto(record);
    }
  };

  const handleDownloadBoth = () => {
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const dl = (url: string, name: string) => {
      const a = document.createElement('a');
      a.href = url;
      a.download = name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    };
    if (frontPhoto?.dataUrl) dl(frontPhoto.dataUrl, `pricelens-sweet-${stamp}.jpg`);
    if (backPhoto?.dataUrl) {
      window.setTimeout(() => dl(backPhoto.dataUrl, `pricelens-scale-${stamp}.jpg`), 250);
    }
  };

  const handleSwitchSource = (nextSource: ScaleCameraSource) => {
    setErrorMsg(null);
    setStage('idle');
    void onUpdateSettings({ ...settings, scaleCameraSource: nextSource });
  };

  const parsedManualGrams = Number.parseFloat(manualWeightGrams);
  const activeWeightKg =
    Number.isFinite(parsedManualGrams) && parsedManualGrams > 0
      ? parsedManualGrams / 1000
      : weightReading?.weightKg ?? 0;

  const priceCalc =
    selectedMatch && activeWeightKg > 0
      ? calculateWeighedPrice(
          selectedMatch.product,
          activeWeightKg,
          settings.currencySymbol
        )
      : null;

  const isBusy = stage !== 'idle';

  const statusPill =
    stage === 'capturing_front'
      ? { text: 'Capturing Sweet...', cls: 'bg-sky-500/15 text-sky-400 border-sky-500/30', icon: <Loader2 className="h-3.5 w-3.5 animate-spin" /> }
      : stage === 'capturing_back'
        ? { text: 'Capturing Scale LCD...', cls: 'bg-sky-500/15 text-sky-400 border-sky-500/30', icon: <Loader2 className="h-3.5 w-3.5 animate-spin" /> }
        : stage === 'analyzing'
          ? { text: 'Calculating Price...', cls: 'bg-amber-500/15 text-amber-400 border-amber-500/30', icon: <Wand2 className="h-3.5 w-3.5 animate-pulse" /> }
          : cameraSource === 'mobile'
            ? phoneCamReady
              ? { text: `Phone ${phoneFacing === 'environment' ? 'Back' : 'Front'} Cam Ready`, cls: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30', icon: <CheckCircle2 className="h-3.5 w-3.5" /> }
              : { text: phoneCamStarting ? 'Starting Phone Cam...' : 'Phone Cam Waiting', cls: 'bg-amber-500/15 text-amber-400 border-amber-500/30', icon: <Smartphone className="h-3.5 w-3.5" /> }
            : wsConnected && espConnected
              ? { text: 'ESP32 Scale Cam Ready', cls: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30', icon: <CheckCircle2 className="h-3.5 w-3.5" /> }
              : wsConnected
                ? { text: 'Relay Online · ESP32 Offline', cls: 'bg-amber-500/15 text-amber-400 border-amber-500/30', icon: <Wifi className="h-3.5 w-3.5" /> }
                : isRelayConfigured
                  ? { text: 'Connecting Relay...', cls: 'bg-rose-500/15 text-rose-400 border-rose-500/30', icon: <WifiOff className="h-3.5 w-3.5" /> }
                  : { text: 'External Cam Not Linked', cls: 'bg-slate-500/15 text-slate-400 border-slate-500/30', icon: <WifiOff className="h-3.5 w-3.5" /> };

  const primaryPipPhoto = pipPrimary === 'front' ? frontPhoto : backPhoto;
  const secondaryPipPhoto = pipPrimary === 'front' ? backPhoto : frontPhoto;

  return (
    <div className="h-full overflow-y-auto bg-slate-50 dark:bg-slate-950 pb-24 md:pb-10">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-5">
        {/* Top Counter Header + Camera Source Switcher */}
        <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 shadow-sm space-y-4">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div className="flex items-start gap-3.5">
              <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-amber-400 to-emerald-500 text-slate-950 flex items-center justify-center shadow-md shrink-0">
                <Scale className="h-6 w-6" strokeWidth={2.4} />
              </div>
              <div>
                <div className="flex items-center gap-2.5 flex-wrap">
                  <h1 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 dark:text-white">
                    Sweet Shop Scale Cam
                  </h1>
                  <span
                    className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full border text-xs font-bold ${statusPill.cls}`}
                  >
                    {statusPill.icon}
                    {statusPill.text}
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
                  {cameraSource === 'mobile'
                    ? 'Using Phone Back + Front cameras to capture sweet & weighing scale display'
                    : 'Using External ESP32-S3 Dual OV5640 (CAM1 GPIO 1 Sweet · CAM2 GPIO 2 Scale)'}
                </p>
              </div>
            </div>

            {/* 2-Option Camera Source Switcher: Phone Dual Cam vs External ESP32 Cam */}
            <div className="inline-flex rounded-2xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-1 self-start lg:self-center">
              <button
                type="button"
                onClick={() => handleSwitchSource('mobile')}
                className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold transition-all ${
                  cameraSource === 'mobile'
                    ? 'bg-emerald-500 text-slate-950 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Smartphone className="h-4 w-4" />
                Phone Dual Cam
              </button>
              <button
                type="button"
                onClick={() => handleSwitchSource('esp32')}
                className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold transition-all ${
                  cameraSource === 'esp32'
                    ? 'bg-amber-400 text-slate-950 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Cpu className="h-4 w-4" />
                External ESP32 Cam
              </button>
            </div>
          </div>

          {/* Action Row */}
          <div className="flex items-center justify-between gap-2.5 flex-wrap pt-3 border-t border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-2.5 flex-wrap">
              {cameraSource === 'mobile' ? (
                <button
                  type="button"
                  disabled={!phoneCamReady || isBusy || products.length === 0}
                  onClick={() => void handlePhoneAutoDualCapture()}
                  className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm shadow-lg transition-all active:scale-[0.98] disabled:opacity-45 disabled:cursor-not-allowed"
                >
                  {isBusy ? (
                    <>
                      <Loader2 className="h-5 w-5 animate-spin" />
                      {statusPill.text}
                    </>
                  ) : (
                    <>
                      <Camera className="h-5 w-5" strokeWidth={2.5} />
                      Auto Dual Capture (Back → Front)
                    </>
                  )}
                </button>
              ) : (
                <button
                  type="button"
                  disabled={!wsConnected || !espConnected || isBusy || products.length === 0}
                  onClick={triggerEspDualCapture}
                  className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-sm shadow-lg transition-all active:scale-[0.98] disabled:opacity-45 disabled:cursor-not-allowed"
                >
                  {isBusy ? (
                    <>
                      <Loader2 className="h-5 w-5 animate-spin" />
                      {statusPill.text}
                    </>
                  ) : (
                    <>
                      <Camera className="h-5 w-5" strokeWidth={2.5} />
                      Weigh &amp; Price (ESP32 Dual Cam)
                    </>
                  )}
                </button>
              )}

              <button
                type="button"
                onClick={() => setShowTestUpload((v) => !v)}
                className="inline-flex items-center gap-1.5 px-3.5 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold border border-slate-200 dark:border-slate-700"
              >
                <Upload className="h-4 w-4" />
                Upload Photos
              </button>

              <button
                type="button"
                disabled={!frontPhoto && !backPhoto}
                onClick={handleDownloadBoth}
                className="inline-flex items-center gap-1.5 px-3.5 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold border border-slate-200 dark:border-slate-700 disabled:opacity-40"
              >
                <Download className="h-4 w-4" />
                Download Both
              </button>
            </div>
          </div>
        </div>

        {/* External ESP32 Relay Setup Prompt */}
        {cameraSource === 'esp32' && !isRelayConfigured && (
          <div className="rounded-2xl bg-amber-500/10 border border-amber-500/30 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="text-xs sm:text-sm text-amber-800 dark:text-amber-200">
              <strong className="font-extrabold">External ESP32-S3 Dual OV5640 not linked yet:</strong>{' '}
              Add your Cloud Relay URL (<code className="font-mono">wss://.../app</code>) and App Token in Settings—or switch to <strong>Phone Dual Cam</strong> above to use your mobile's front &amp; back cameras immediately.
            </div>
            <button
              type="button"
              onClick={onOpenSettings}
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-extrabold shrink-0"
            >
              <SettingsIcon className="h-4 w-4" />
              Configure Relay
            </button>
          </div>
        )}

        {/* Empty Catalog Prompt */}
        {products.length === 0 && (
          <div className="rounded-2xl bg-emerald-500/10 border border-emerald-500/30 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <p className="text-xs sm:text-sm font-semibold text-emerald-800 dark:text-emerald-200">
              Add your sweets (e.g., Kaju Katli ₹840 / kg, Mysore Pak ₹620 / kg) in Catalog first so Scale Cam can identify and price them.
            </p>
            <button
              type="button"
              onClick={onAddFirstProduct}
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-500 text-slate-950 text-xs font-extrabold shrink-0"
            >
              <Plus className="h-4 w-4" />
              Add First Sweet
            </button>
          </div>
        )}

        {/* Error Banner */}
        {errorMsg && (
          <div className="flex items-center justify-between gap-3 px-4 py-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-300 text-xs sm:text-sm font-semibold">
            <span className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4 shrink-0" />
              {errorMsg}
            </span>
            {cameraSource === 'esp32' && isRelayConfigured && !wsConnected && (
              <button
                type="button"
                onClick={connectWebSocket}
                className="inline-flex items-center gap-1 px-3 py-1 rounded-lg bg-rose-500/20 text-xs font-bold"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                Retry
              </button>
            )}
          </div>
        )}

        {/* LIVE PHONE DUAL CAMERA PREVIEW STAGE (when Phone Dual Cam is active) */}
        {cameraSource === 'mobile' && (
          <section className="rounded-3xl bg-slate-900 border border-slate-800 overflow-hidden shadow-lg">
            <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800">
              <span className="inline-flex items-center gap-2 text-xs sm:text-sm font-extrabold text-white">
                <span
                  className={`h-2.5 w-2.5 rounded-full ${
                    phoneFacing === 'environment' ? 'bg-emerald-400' : 'bg-amber-400'
                  }`}
                />
                Live Phone Viewfinder ·{' '}
                {phoneFacing === 'environment'
                  ? 'Back Camera (Aim at Sweet)'
                  : 'Front Camera (Aim at Scale LCD)'}
              </span>

              <button
                type="button"
                disabled={isBusy}
                onClick={() =>
                  void startPhoneCamera(
                    phoneFacing === 'environment' ? 'user' : 'environment'
                  )
                }
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold text-white disabled:opacity-40"
              >
                <SwitchCamera className="h-3.5 w-3.5" />
                Flip to {phoneFacing === 'environment' ? 'Front' : 'Back'}
              </button>
            </div>

            <div className="relative aspect-[16/10] sm:aspect-[21/9] bg-black overflow-hidden">
              <video
                ref={phoneVideoRef}
                playsInline
                muted
                autoPlay
                className="h-full w-full object-cover"
              />

              {phoneCamStarting && (
                <div className="absolute inset-0 flex items-center justify-center bg-slate-950/80 text-white gap-2 text-xs font-bold">
                  <Loader2 className="h-5 w-5 animate-spin text-emerald-400" />
                  Switching phone lens...
                </div>
              )}

              {/* Manual 2-Step Quick-Snap Controls */}
              <div className="absolute bottom-3 inset-x-3 flex items-center justify-center gap-2 flex-wrap">
                <button
                  type="button"
                  disabled={!phoneCamReady || isBusy}
                  onClick={() => void handlePhoneSnapSingle('sweet')}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-emerald-500/95 hover:bg-emerald-400 text-slate-950 text-xs font-extrabold shadow-lg backdrop-blur disabled:opacity-40"
                >
                  <Camera className="h-3.5 w-3.5" />
                  1. Snap Sweet
                </button>
                <button
                  type="button"
                  disabled={!phoneCamReady || isBusy}
                  onClick={() => void handlePhoneSnapSingle('scale')}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-amber-400/95 hover:bg-amber-300 text-slate-950 text-xs font-extrabold shadow-lg backdrop-blur disabled:opacity-40"
                >
                  <Scale className="h-3.5 w-3.5" />
                  2. Snap Scale &amp; Price
                </button>
              </div>
            </div>
          </section>
        )}

        {/* Optional Local Photo Uploader */}
        {showTestUpload && (
          <div className="rounded-3xl bg-white dark:bg-slate-900 border border-sky-500/40 p-4 sm:p-5 space-y-3 shadow-sm">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h2 className="text-sm font-extrabold text-slate-900 dark:text-white">
                Upload Sweet + Scale Display Photos
              </h2>
              <button
                type="button"
                disabled={!frontPhoto || !backPhoto || isBusy}
                onClick={() => {
                  if (frontPhoto && backPhoto) {
                    void runDualAnalysis(frontPhoto.dataUrl, backPhoto.dataUrl);
                  }
                }}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs font-extrabold disabled:opacity-40"
              >
                <Wand2 className="h-3.5 w-3.5" />
                Run Sweet + Scale Price Check
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => testFrontInputRef.current?.click()}
                className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200 border border-dashed border-slate-300 dark:border-slate-700"
              >
                <Upload className="h-4 w-4 text-emerald-500" />
                {frontPhoto ? 'Replace Sweet Photo' : '1. Upload Sweet Photo'}
              </button>
              <button
                type="button"
                onClick={() => testBackInputRef.current?.click()}
                className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200 border border-dashed border-slate-300 dark:border-slate-700"
              >
                <Upload className="h-4 w-4 text-sky-500" />
                {backPhoto ? 'Replace Scale Display Photo' : '2. Upload Scale Display Photo'}
              </button>
              <input
                ref={testFrontInputRef}
                type="file"
                accept="image/*"
                onChange={(e) => void handleLocalTestUpload('front', e)}
                className="hidden"
              />
              <input
                ref={testBackInputRef}
                type="file"
                accept="image/*"
                onChange={(e) => void handleLocalTestUpload('back', e)}
                className="hidden"
              />
            </div>
          </div>
        )}

        {/* HERO COUNTER PRICE RESULT CARD */}
        {(selectedMatch || weightReading) && (
          <section className="rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 text-white border border-emerald-500/40 shadow-pos-card p-5 sm:p-7 animate-slide-up">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
              <div className="flex items-start gap-4 min-w-0">
                {selectedMatch?.product.angles[0]?.thumbnail && (
                  <img
                    src={selectedMatch.product.angles[0].thumbnail}
                    alt={selectedMatch.product.name}
                    className="h-20 w-20 sm:h-24 sm:w-24 rounded-2xl object-cover border border-white/15 shrink-0 bg-slate-800"
                  />
                )}
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    {selectedMatch && (
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-extrabold ${
                          selectedMatch.source === 'cloud'
                            ? 'bg-sky-500/20 text-sky-300'
                            : 'bg-emerald-500/20 text-emerald-300'
                        }`}
                      >
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        {selectedMatch.source === 'cloud' ? 'AI Verified' : 'Local Match'} ·{' '}
                        {Math.round(selectedMatch.score * 100)}%
                      </span>
                    )}
                    {selectedMatch?.product.category && (
                      <span className="px-2.5 py-0.5 rounded-full bg-white/10 text-slate-300 text-xs font-semibold">
                        {selectedMatch.product.category}
                      </span>
                    )}
                  </div>

                  <h2 className="text-2xl sm:text-3xl font-black tracking-tight mt-1.5 truncate">
                    {selectedMatch ? selectedMatch.product.name : 'Select Sweet Below'}
                  </h2>

                  {selectedMatch && (
                    <p className="text-sm font-bold text-slate-300 mt-1">
                      Rate:{' '}
                      <span className="text-amber-300">
                        {formatPrice(selectedMatch.product.basePrice, settings.currencySymbol)}{' '}
                        {selectedMatch.product.unit
                          ? `/ ${selectedMatch.product.unit.replace(/^per\s+/i, '')}`
                          : '/ kg'}
                      </span>
                    </p>
                  )}

                  <div className="mt-3 flex items-center gap-2.5 flex-wrap">
                    <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-white/10 border border-white/15">
                      <Scale className="h-4 w-4 text-amber-400" />
                      <span className="text-sm font-extrabold text-white">
                        {activeWeightKg > 0 ? formatWeightDisplay(activeWeightKg) : 'Weight needed'}
                      </span>
                      {weightReading?.rawDisplayText && (
                        <span className="text-[11px] font-mono text-slate-400">
                          (LCD: {weightReading.rawDisplayText})
                        </span>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => setEditingWeight((v) => !v)}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/15 text-xs font-bold text-slate-300"
                    >
                      <Edit3 className="h-3.5 w-3.5" />
                      {editingWeight ? 'Done' : 'Adjust Weight'}
                    </button>
                  </div>

                  {editingWeight && (
                    <div className="mt-2.5 flex items-center gap-2">
                      <input
                        type="number"
                        min="1"
                        step="5"
                        value={manualWeightGrams}
                        onChange={(e) => setManualWeightGrams(e.target.value)}
                        placeholder="Weight in grams (e.g. 250)"
                        className="w-48 px-3 py-1.5 rounded-xl bg-slate-950 border border-white/20 text-sm font-bold text-white focus:outline-none focus:ring-2 focus:ring-amber-400"
                      />
                      <span className="text-xs font-bold text-slate-400">grams</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="lg:text-right border-t lg:border-t-0 lg:border-l border-white/10 pt-4 lg:pt-0 lg:pl-7 shrink-0">
                <p className="text-xs font-bold uppercase tracking-widest text-slate-400">
                  Calculated Counter Price
                </p>
                <p className="text-5xl sm:text-6xl font-black tracking-tight text-emerald-400 mt-1">
                  {priceCalc
                    ? formatPrice(priceCalc.totalPrice, settings.currencySymbol)
                    : selectedMatch
                      ? formatPrice(selectedMatch.product.basePrice, settings.currencySymbol)
                      : '—'}
                </p>
                {priceCalc && (
                  <p className="text-xs sm:text-sm font-semibold text-slate-300 mt-1.5">
                    {priceCalc.formulaText}
                  </p>
                )}
              </div>
            </div>

            {candidateMatches.length > 1 && (
              <div className="mt-5 pt-4 border-t border-white/10 flex items-center gap-2 flex-wrap">
                <span className="inline-flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-slate-400 mr-1">
                  <Sparkles className="h-3.5 w-3.5 text-amber-400" />
                  Switch Sweet:
                </span>
                {candidateMatches.map((m) => {
                  const isActive = selectedMatch?.product.id === m.product.id;
                  return (
                    <button
                      key={m.product.id}
                      type="button"
                      onClick={() => setSelectedMatch(m)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                        isActive
                          ? 'bg-emerald-500 text-slate-950'
                          : 'bg-white/10 text-slate-200 hover:bg-white/20'
                      }`}
                    >
                      {m.product.name} ({Math.round(m.score * 100)}%)
                    </button>
                  );
                })}
              </div>
            )}
          </section>
        )}

        {/* Mobile Stacked vs PiP Toggle */}
        <div className="md:hidden flex justify-end">
          <div className="inline-flex rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-1">
            <button
              type="button"
              onClick={() => setMobileLayout('stacked')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold ${
                mobileLayout === 'stacked'
                  ? 'bg-emerald-500 text-slate-950'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Layers className="h-3.5 w-3.5" />
              Stacked
            </button>
            <button
              type="button"
              onClick={() => setMobileLayout('pip')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold ${
                mobileLayout === 'pip'
                  ? 'bg-emerald-500 text-slate-950'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <PictureInPicture2 className="h-3.5 w-3.5" />
              PiP
            </button>
          </div>
        </div>

        {/* Desktop Side-by-Side Captured Dual View */}
        <div className="hidden md:grid md:grid-cols-2 gap-4">
          {[
            {
              title:
                cameraSource === 'mobile'
                  ? 'Sweet Capture (Phone Back Cam)'
                  : 'Front Camera · Sweet Pan (CAM1)',
              photo: frontPhoto,
              dot: 'bg-emerald-400',
              hint: 'Captured photo of the sweet on the weighing pan',
            },
            {
              title:
                cameraSource === 'mobile'
                  ? 'Scale Display (Phone Front Cam)'
                  : 'Back Camera · Scale Display (CAM2)',
              photo: backPhoto,
              dot: 'bg-amber-400',
              hint: 'Captured photo of the digital scale weight readout',
            },
          ].map((cam) => (
            <div
              key={cam.title}
              className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm flex flex-col"
            >
              <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 dark:border-slate-800">
                <span className="inline-flex items-center gap-2 text-sm font-extrabold text-slate-900 dark:text-white">
                  <span className={`h-2.5 w-2.5 rounded-full ${cam.dot}`} />
                  {cam.title}
                </span>
                <span className="text-xs font-mono text-slate-500 dark:text-slate-400">
                  {cam.photo?.timestamp || 'Waiting'}
                </span>
              </div>
              <div className="aspect-[4/3] bg-slate-100 dark:bg-slate-950 flex items-center justify-center overflow-hidden">
                {cam.photo?.dataUrl ? (
                  <img
                    src={cam.photo.dataUrl}
                    alt={cam.title}
                    className="h-full w-full object-contain"
                  />
                ) : (
                  <div className="text-center px-6 text-slate-400">
                    <Camera className="h-10 w-10 mx-auto mb-2 opacity-40" />
                    <p className="text-xs font-semibold">{cam.hint}</p>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Mobile Stacked / PiP Captured View */}
        <div className="md:hidden">
          {mobileLayout === 'stacked' ? (
            <div className="space-y-4">
              {[
                {
                  title:
                    cameraSource === 'mobile'
                      ? 'Sweet Capture (Back Cam)'
                      : 'Front Camera · Sweet Pan (CAM1)',
                  photo: frontPhoto,
                  dot: 'bg-emerald-400',
                },
                {
                  title:
                    cameraSource === 'mobile'
                      ? 'Scale Display (Front Cam)'
                      : 'Back Camera · Scale Display (CAM2)',
                  photo: backPhoto,
                  dot: 'bg-amber-400',
                },
              ].map((cam) => (
                <div
                  key={cam.title}
                  className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm"
                >
                  <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 dark:border-slate-800">
                    <span className="inline-flex items-center gap-2 text-xs font-extrabold text-slate-900 dark:text-white">
                      <span className={`h-2.5 w-2.5 rounded-full ${cam.dot}`} />
                      {cam.title}
                    </span>
                    <span className="text-[11px] font-mono text-slate-500">
                      {cam.photo?.timestamp || 'Waiting'}
                    </span>
                  </div>
                  <div className="aspect-[4/3] bg-slate-100 dark:bg-slate-950 flex items-center justify-center">
                    {cam.photo?.dataUrl ? (
                      <img src={cam.photo.dataUrl} alt={cam.title} className="h-full w-full object-contain" />
                    ) : (
                      <Camera className="h-9 w-9 text-slate-400 opacity-40" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="relative rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-md">
              <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 dark:border-slate-800">
                <span className="text-xs font-extrabold text-slate-900 dark:text-white">
                  {pipPrimary === 'front' ? 'Sweet Capture' : 'Scale Display'}
                </span>
                <span className="text-[11px] font-mono text-slate-500">
                  {primaryPipPhoto?.timestamp || 'Waiting'}
                </span>
              </div>
              <div className="relative aspect-[4/3] bg-slate-950 flex items-center justify-center">
                {primaryPipPhoto?.dataUrl ? (
                  <img src={primaryPipPhoto.dataUrl} alt="Primary capture" className="h-full w-full object-contain" />
                ) : (
                  <Camera className="h-10 w-10 text-slate-500 opacity-40" />
                )}
                <button
                  type="button"
                  onClick={() => setPipPrimary((p) => (p === 'front' ? 'back' : 'front'))}
                  className="absolute bottom-3 right-3 w-32 aspect-[4/3] rounded-2xl overflow-hidden bg-slate-900 border-2 border-emerald-400 shadow-2xl"
                >
                  {secondaryPipPhoto?.dataUrl ? (
                    <img src={secondaryPipPhoto.dataUrl} alt="Secondary capture" className="h-full w-full object-cover" />
                  ) : (
                    <div className="h-full w-full flex items-center justify-center text-[10px] font-bold text-slate-400">
                      Swap View
                    </div>
                  )}
                  <span className="absolute bottom-1 left-1 px-1.5 py-0.5 rounded bg-slate-950/80 text-[9px] font-extrabold text-white">
                    {pipPrimary === 'front' ? 'Scale' : 'Sweet'} · Swap
                  </span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
