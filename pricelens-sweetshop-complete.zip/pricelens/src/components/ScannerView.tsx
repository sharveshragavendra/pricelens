import { useCallback, useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  Camera,
  CameraOff,
  CheckCircle2,
  Loader2,
  Moon,
  Pause,
  Play,
  Plus,
  RefreshCw,
  Sparkles,
  SwitchCamera,
  Wand2,
  X,
} from 'lucide-react';
import { useCamera } from '../hooks/useCamera';
import type { ModelState } from '../hooks/useModel';
import { identifyWithCloudAI } from '../services/cloudVision';
import { captureVideoFrameAsDataUrl, formatPrice } from '../services/imageUtils';
import {
  analyzeFrameQuality,
  extractDualScaleViewfinderEmbeddings,
  matchProductsMultiCrop,
  TemporalSmoother,
} from '../services/visionEngine';
import {
  UNCERTAIN_MIN_THRESHOLD,
  type AppSettings,
  type CloudAiProvider,
  type CloudVisionStatus,
  type FrameQualityResult,
  type Product,
  type ProductMatch,
} from '../types';

interface ScannerViewProps {
  products: Product[];
  settings: AppSettings;
  modelState: ModelState;
  cloudStatus: CloudVisionStatus;
  onAddFirstProduct: () => void;
}

const AUTO_ESCALATE_COOLDOWN_MS = 3200;

function providerShortLabel(provider: CloudAiProvider): string {
  if (provider === 'openrouter') return 'Gemma 4 31B';
  if (provider === 'claude') return 'Claude Haiku';
  return 'Gemini Flash-Lite';
}

export function ScannerView({
  products,
  settings,
  modelState,
  cloudStatus,
  onAddFirstProduct,
}: ScannerViewProps) {
  const [isPaused, setIsPaused] = useState(false);
  const [showCameraPicker, setShowCameraPicker] = useState(false);

  const [confirmedMatch, setConfirmedMatch] = useState<ProductMatch | null>(null);
  const [uncertainMatches, setUncertainMatches] = useState<ProductMatch[]>([]);
  const [pinnedFallback, setPinnedFallback] = useState<ProductMatch | null>(null);
  const [cloudLock, setCloudLock] = useState<ProductMatch | null>(null);
  const [cloudBusy, setCloudBusy] = useState(false);
  const [cloudError, setCloudError] = useState<string | null>(null);

  const [frameQuality, setFrameQuality] = useState<FrameQualityResult>({
    status: 'good',
    label: null,
    brightness: 128,
    motion: 0,
  });

  const qualityCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const cropCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const prevGrayRef = useRef<Uint8ClampedArray | null>(null);
  const smootherRef = useRef<TemporalSmoother>(new TemporalSmoother(3));
  const isScanningFrameRef = useRef(false);
  const latestTopCandidatesRef = useRef<Product[]>([]);
  const lastAutoCloudAtRef = useRef<number>(0);
  const cloudBusyRef = useRef<boolean>(false);

  const {
    videoRef,
    isReady: cameraReady,
    isStarting: cameraStarting,
    error: cameraError,
    devices,
    selectedDeviceId,
    switchCamera,
    selectDevice,
    retry: retryCamera,
  } = useCamera({ enabled: true, preferredFacingMode: 'environment' });

  const selectedProviderConfigured =
    settings.cloudAiProvider === 'openrouter'
      ? cloudStatus.openrouterConfigured
      : settings.cloudAiProvider === 'claude'
        ? cloudStatus.claudeConfigured
        : cloudStatus.geminiConfigured;

  const activeProviderName = providerShortLabel(settings.cloudAiProvider);

  useEffect(() => {
    smootherRef.current.reset();
    latestTopCandidatesRef.current = products.slice(0, 10);
    if (products.length === 0) {
      setConfirmedMatch(null);
      setUncertainMatches([]);
      setPinnedFallback(null);
      setCloudLock(null);
    }
  }, [products]);

  const runSmartCloudScan = useCallback(
    async (isAutoTrigger = false) => {
      const video = videoRef.current;
      if (!video || !cameraReady || products.length === 0 || cloudBusyRef.current) return;

      cloudBusyRef.current = true;
      setCloudBusy(true);
      if (!isAutoTrigger) {
        setCloudError(null);
      }

      try {
        const croppedImage = captureVideoFrameAsDataUrl(video, 384, 0.85, 0.68);
        const shortlist =
          latestTopCandidatesRef.current.length > 0
            ? latestTopCandidatesRef.current.slice(0, 10)
            : products.slice(0, 10);

        const result = await identifyWithCloudAI({
          imageBase64: croppedImage,
          provider: settings.cloudAiProvider,
          candidates: shortlist,
        });

        if (result.matchedProductId) {
          const matchedProduct = products.find((p) => p.id === result.matchedProductId);
          if (matchedProduct) {
            setCloudLock({
              product: matchedProduct,
              score: Math.max(result.confidence, 0.85),
              bestAngleId: matchedProduct.angles[0]?.id ?? 'cloud',
              source: 'cloud',
              matchedVariantId: result.matchedVariantId,
              cloudModel: result.model,
              cloudReason: result.reason,
            });
            setPinnedFallback(null);
            setCloudError(null);
            return;
          }
        }

        if (!isAutoTrigger) {
          setCloudError('No clear match found in your catalog. Center the label and try again.');
        }
      } catch (err) {
        if (!isAutoTrigger) {
          setCloudError(
            err instanceof Error
              ? err.message
              : 'Smart Scan failed. Check your API key in Vercel Environment Variables.'
          );
        }
      } finally {
        cloudBusyRef.current = false;
        setCloudBusy(false);
      }
    },
    [cameraReady, products, settings.cloudAiProvider, videoRef]
  );

  useEffect(() => {
    if (!cameraReady || !modelState.ready || isPaused || products.length === 0) {
      return;
    }

    if (!qualityCanvasRef.current) {
      qualityCanvasRef.current = document.createElement('canvas');
    }
    if (!cropCanvasRef.current) {
      cropCanvasRef.current = document.createElement('canvas');
    }

    const tick = () => {
      if (isScanningFrameRef.current || cloudLock) return;
      const video = videoRef.current;
      if (!video || video.readyState < 2 || video.videoWidth === 0) return;

      isScanningFrameRef.current = true;
      try {
        const { quality, nextGray } = analyzeFrameQuality(
          video,
          qualityCanvasRef.current!,
          prevGrayRef.current
        );
        prevGrayRef.current = nextGray;
        setFrameQuality(quality);

        const cropEmbeddings = extractDualScaleViewfinderEmbeddings(
          video,
          cropCanvasRef.current!
        );
        if (cropEmbeddings.length === 0) return;

        const { ranked, hasClearLead } = matchProductsMultiCrop(
          cropEmbeddings,
          products
        );
        latestTopCandidatesRef.current = ranked.slice(0, 10).map((m) => m.product);

        const top = ranked[0] ?? null;
        const smoothed = smootherRef.current.push(top, UNCERTAIN_MIN_THRESHOLD);

        if (
          smoothed.stableProductId &&
          smoothed.smoothedScore >= settings.confidenceThreshold &&
          hasClearLead
        ) {
          const matchedEntry = ranked.find(
            (m) => m.product.id === smoothed.stableProductId
          );
          if (matchedEntry) {
            setConfirmedMatch({
              ...matchedEntry,
              score: smoothed.smoothedScore,
              source: 'local',
            });
            setUncertainMatches([]);
            setPinnedFallback(null);
            return;
          }
        }

        if (top && top.score >= UNCERTAIN_MIN_THRESHOLD) {
          setConfirmedMatch(null);
          setUncertainMatches(ranked.filter((m) => m.score >= 0.45).slice(0, 3));

          const now = Date.now();
          if (
            settings.hybridMode === 'auto' &&
            selectedProviderConfigured &&
            quality.status === 'good' &&
            !cloudBusyRef.current &&
            now - lastAutoCloudAtRef.current >= AUTO_ESCALATE_COOLDOWN_MS
          ) {
            lastAutoCloudAtRef.current = now;
            void runSmartCloudScan(true);
          }
        } else {
          setConfirmedMatch(null);
          setUncertainMatches([]);
        }
      } catch {
        // Skip transient frame errors
      } finally {
        isScanningFrameRef.current = false;
      }
    };

    const intervalId = window.setInterval(tick, settings.scanIntervalMs);
    return () => {
      window.clearInterval(intervalId);
    };
  }, [
    cameraReady,
    modelState.ready,
    isPaused,
    products,
    cloudLock,
    settings.confidenceThreshold,
    settings.scanIntervalMs,
    settings.hybridMode,
    selectedProviderConfigured,
    runSmartCloudScan,
    videoRef,
  ]);

  const activeCardMatch = cloudLock ?? pinnedFallback ?? confirmedMatch;
  const viewfinderColor = activeCardMatch
    ? activeCardMatch.source === 'cloud'
      ? 'border-sky-400 shadow-[0_0_26px_rgba(56,189,248,0.55)]'
      : 'border-emerald-400 shadow-[0_0_24px_rgba(16,185,129,0.5)]'
    : uncertainMatches.length > 0
      ? 'border-amber-400'
      : 'border-white/80';

  const handleTogglePause = () => {
    setIsPaused((prev) => {
      if (prev) {
        smootherRef.current.reset();
        setPinnedFallback(null);
        setCloudLock(null);
      }
      return !prev;
    });
  };

  const handleDismissCard = () => {
    setCloudLock(null);
    setPinnedFallback(null);
    setCloudError(null);
    smootherRef.current.reset();
  };

  return (
    <div className="relative h-full w-full bg-slate-950 overflow-hidden select-none">
      <video
        ref={videoRef}
        playsInline
        muted
        autoPlay
        className={`h-full w-full object-cover transition-opacity duration-300 ${
          cameraReady ? 'opacity-100' : 'opacity-0'
        }`}
      />

      <div className="pointer-events-none absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-slate-950/80 via-slate-950/35 to-transparent z-10" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-60 bg-gradient-to-t from-slate-950/90 via-slate-950/45 to-transparent z-10" />

      {/* Top Control Bar */}
      <header className="absolute top-0 inset-x-0 z-20 px-4 pt-4 sm:px-6 sm:pt-5 flex items-start justify-between gap-3">
        <div className="flex flex-col items-start gap-2">
          <div className="flex items-center gap-2 px-3.5 py-2 rounded-full bg-slate-950/75 backdrop-blur-md border border-white/15 text-white shadow-lg">
            {modelState.loading ? (
              <>
                <Loader2 className="h-4 w-4 text-emerald-400 animate-spin shrink-0" />
                <span className="text-xs font-semibold whitespace-nowrap">
                  {modelState.stage} ({modelState.progress}%)
                </span>
              </>
            ) : modelState.error ? (
              <button
                type="button"
                onClick={modelState.retry}
                className="flex items-center gap-2 text-xs font-semibold text-rose-300"
              >
                <AlertTriangle className="h-4 w-4 shrink-0" />
                <span>AI Failed — Tap to Retry</span>
              </button>
            ) : (
              <>
                <span className="h-2.5 w-2.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                <span className="text-xs font-bold tracking-wide">
                  AI Ready
                  {settings.hybridMode !== 'off' && (
                    <span className="text-sky-300 font-semibold ml-1.5">
                      · {activeProviderName}
                    </span>
                  )}
                </span>
              </>
            )}
          </div>

          {cameraReady && !isPaused && frameQuality.label && products.length > 0 && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-500/95 text-slate-950 text-xs font-bold shadow-lg animate-slide-up">
              {frameQuality.status === 'too_dark' ? (
                <Moon className="h-3.5 w-3.5" />
              ) : (
                <AlertTriangle className="h-3.5 w-3.5" />
              )}
              <span>{frameQuality.label}</span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2 relative">
          <button
            type="button"
            onClick={handleTogglePause}
            aria-label={isPaused ? 'Resume live scanning' : 'Pause live scanning'}
            className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-full backdrop-blur-md border text-xs font-bold shadow-lg transition-all active:scale-95 ${
              isPaused
                ? 'bg-amber-400 text-slate-950 border-amber-300'
                : 'bg-slate-950/75 text-white border-white/15 hover:bg-slate-900'
            }`}
          >
            {isPaused ? (
              <>
                <Play className="h-4 w-4 fill-current" />
                <span className="hidden sm:inline">Resume</span>
              </>
            ) : (
              <>
                <Pause className="h-4 w-4" />
                <span className="hidden sm:inline">Pause</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => {
              if (devices.length > 2) {
                setShowCameraPicker((v) => !v);
              } else {
                switchCamera();
              }
            }}
            aria-label="Switch camera"
            title="Switch camera"
            className="flex items-center justify-center h-10 w-10 rounded-full bg-slate-950/75 hover:bg-slate-900 text-white backdrop-blur-md border border-white/15 shadow-lg transition-all active:scale-95"
          >
            <SwitchCamera className="h-5 w-5" />
          </button>

          {showCameraPicker && devices.length > 1 && (
            <div className="absolute right-0 top-12 w-60 rounded-2xl bg-slate-900/95 backdrop-blur-md border border-white/15 p-2 shadow-2xl z-30">
              <div className="flex items-center justify-between px-2.5 py-1.5 border-b border-white/10 mb-1">
                <span className="text-xs font-bold text-slate-300">Select Camera</span>
                <button
                  type="button"
                  onClick={() => setShowCameraPicker(false)}
                  className="text-slate-400 hover:text-white"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
              {devices.map((device) => (
                <button
                  key={device.deviceId}
                  type="button"
                  onClick={() => {
                    selectDevice(device.deviceId);
                    setShowCameraPicker(false);
                  }}
                  className={`w-full text-left px-2.5 py-2 rounded-xl text-xs font-semibold truncate transition-colors ${
                    device.deviceId === selectedDeviceId
                      ? 'bg-emerald-500 text-slate-950'
                      : 'text-slate-200 hover:bg-white/10'
                  }`}
                >
                  {device.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </header>

      {/* Center Corner-Bracket Viewfinder */}
      {cameraReady && !cameraError && products.length > 0 && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center z-10 pb-28 md:pb-16">
          <div className="relative w-60 h-60 sm:w-72 sm:h-72">
            <div
              className={`absolute top-0 left-0 w-10 h-10 border-t-4 border-l-4 rounded-tl-2xl transition-colors duration-200 ${viewfinderColor}`}
            />
            <div
              className={`absolute top-0 right-0 w-10 h-10 border-t-4 border-r-4 rounded-tr-2xl transition-colors duration-200 ${viewfinderColor}`}
            />
            <div
              className={`absolute bottom-0 left-0 w-10 h-10 border-b-4 border-l-4 rounded-bl-2xl transition-colors duration-200 ${viewfinderColor}`}
            />
            <div
              className={`absolute bottom-0 right-0 w-10 h-10 border-b-4 border-r-4 rounded-br-2xl transition-colors duration-200 ${viewfinderColor}`}
            />

            {!isPaused && !activeCardMatch && (
              <div className="absolute inset-x-4 top-1/2 h-0.5 bg-emerald-400/50 rounded-full animate-scan-pulse" />
            )}

            {cloudBusy && (
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-950/85 border border-sky-400/50 text-sky-300 text-xs font-bold shadow-xl">
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  Reading label with {activeProviderName}...
                </span>
              </div>
            )}

            {isPaused && !cloudBusy && (
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="px-4 py-1.5 rounded-full bg-slate-950/80 border border-white/20 text-white text-xs font-bold tracking-wider uppercase">
                  Scanning Paused
                </span>
              </div>
            )}
          </div>
        </div>
      )}

      {cameraStarting && !cameraError && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950 text-white z-10 gap-3">
          <Loader2 className="h-9 w-9 text-emerald-400 animate-spin" />
          <p className="text-sm font-semibold text-slate-300">Starting camera...</p>
        </div>
      )}

      {cameraError && (
        <div className="absolute inset-0 flex items-center justify-center p-6 bg-slate-950/95 z-20">
          <div className="max-w-md w-full rounded-3xl bg-slate-900 border border-slate-800 p-6 text-center shadow-2xl">
            <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-rose-500/15 text-rose-400">
              <CameraOff className="h-7 w-7" />
            </div>
            <h2 className="text-lg font-bold text-white">Camera Access Needed</h2>
            <p className="text-sm text-slate-300 mt-2 leading-relaxed">
              {cameraError.message}
            </p>
            {cameraError.type === 'permission_denied' && (
              <div className="mt-4 rounded-2xl bg-slate-950/80 border border-slate-800 p-3.5 text-left text-xs text-slate-300 space-y-1.5">
                <p className="font-bold text-slate-100">How to enable camera access:</p>
                <p>1. Tap the lock or camera icon in your browser address bar.</p>
                <p>2. Set Camera permission to Allow for this site.</p>
                <p>3. Tap Retry Camera below (or reload the page).</p>
              </div>
            )}
            <button
              type="button"
              onClick={retryCamera}
              className="mt-5 w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm transition-colors"
            >
              <RefreshCw className="h-4 w-4" />
              Retry Camera
            </button>
          </div>
        </div>
      )}

      {!cameraError && products.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center p-6 z-20 pb-24 md:pb-6">
          <div className="max-w-sm w-full rounded-3xl bg-slate-900/90 backdrop-blur-xl border border-white/15 p-6 text-center shadow-2xl">
            <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-500/15 text-emerald-400">
              <Camera className="h-7 w-7" />
            </div>
            <h2 className="text-xl font-extrabold text-white">Your Catalog Is Empty</h2>
            <p className="text-sm text-slate-300 mt-2 leading-relaxed">
              Register a product with 1–5 quick photos so PriceLens can recognize it and display its price instantly.
            </p>
            <button
              type="button"
              onClick={onAddFirstProduct}
              className="mt-5 w-full flex items-center justify-center gap-2 py-3.5 px-5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-sm shadow-lg transition-transform active:scale-[0.98]"
            >
              <Plus className="h-5 w-5" strokeWidth={2.5} />
              Add your first product to start scanning
            </button>
          </div>
        </div>
      )}

      {/* Bottom Results Overlay Area */}
      {!cameraError && products.length > 0 && (
        <div className="absolute inset-x-0 bottom-20 md:bottom-6 z-20 px-4 sm:px-6 flex flex-col items-center gap-2.5 pointer-events-none">
          {cloudError && (
            <div className="pointer-events-auto max-w-md w-full flex items-center justify-between gap-2 px-4 py-2.5 rounded-2xl bg-rose-950/95 border border-rose-500/40 text-rose-200 text-xs font-semibold shadow-xl">
              <span>{cloudError}</span>
              <button
                type="button"
                onClick={() => setCloudError(null)}
                className="text-rose-300 hover:text-white shrink-0"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          )}

          {settings.hybridMode !== 'off' && cameraReady && !cloudLock && (
            <button
              type="button"
              disabled={cloudBusy}
              onClick={() => void runSmartCloudScan(false)}
              className="pointer-events-auto inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs sm:text-sm font-extrabold shadow-xl transition-all active:scale-95 disabled:opacity-60"
            >
              {cloudBusy ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Identifying...
                </>
              ) : (
                <>
                  <Wand2 className="h-4 w-4" strokeWidth={2.5} />
                  Smart Scan ({activeProviderName})
                </>
              )}
            </button>
          )}

          {activeCardMatch && (
            <div
              className={`pointer-events-auto w-full max-w-xl rounded-3xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white border shadow-pos-card p-5 sm:p-6 animate-slide-up ${
                activeCardMatch.source === 'cloud'
                  ? 'border-sky-400/70'
                  : 'border-slate-200/80 dark:border-emerald-500/40'
              }`}
            >
              <div className="flex items-start gap-4">
                {activeCardMatch.product.angles[0]?.thumbnail && (
                  <img
                    src={activeCardMatch.product.angles[0].thumbnail}
                    alt={activeCardMatch.product.name}
                    className="h-20 w-20 sm:h-24 sm:w-24 rounded-2xl object-cover border border-slate-200 dark:border-slate-700 shrink-0 bg-slate-100 dark:bg-slate-800"
                  />
                )}

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      {activeCardMatch.source === 'cloud' ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-sky-500/15 text-sky-700 dark:text-sky-300 text-xs font-extrabold">
                          <Wand2 className="h-3.5 w-3.5" />
                          AI Verified · {Math.round(activeCardMatch.score * 100)}%
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 text-xs font-extrabold">
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          {Math.round(activeCardMatch.score * 100)}% match
                        </span>
                      )}

                      {activeCardMatch.product.category && (
                        <span className="px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-semibold">
                          {activeCardMatch.product.category}
                        </span>
                      )}
                    </div>

                    {(pinnedFallback || cloudLock) && (
                      <button
                        type="button"
                        onClick={handleDismissCard}
                        aria-label="Scan next item"
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white text-[11px] font-bold"
                      >
                        <X className="h-3.5 w-3.5" />
                        Next
                      </button>
                    )}
                  </div>

                  <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight truncate mt-1.5">
                    {activeCardMatch.product.name}
                  </h2>

                  <div className="flex items-baseline gap-2 mt-1 flex-wrap">
                    <span className="text-4xl sm:text-5xl font-black tracking-tight text-emerald-600 dark:text-emerald-400">
                      {formatPrice(
                        activeCardMatch.product.basePrice,
                        settings.currencySymbol
                      )}
                    </span>
                    {activeCardMatch.product.unit && (
                      <span className="text-base sm:text-lg font-bold text-slate-500 dark:text-slate-400">
                        / {activeCardMatch.product.unit.replace(/^per\s+/i, '')}
                      </span>
                    )}
                  </div>

                  {activeCardMatch.cloudReason && (
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 truncate">
                      {activeCardMatch.cloudReason}
                    </p>
                  )}
                </div>
              </div>

              {activeCardMatch.product.variants.length > 0 && (
                <div className="mt-4 pt-3.5 border-t border-slate-200 dark:border-slate-800 flex flex-wrap gap-2">
                  {activeCardMatch.product.variants.map((variant) => {
                    const isMatchedVariant =
                      activeCardMatch.matchedVariantId === variant.id;
                    return (
                      <div
                        key={variant.id}
                        className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl border ${
                          isMatchedVariant
                            ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-sm'
                            : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        <span
                          className={`text-xs sm:text-sm font-semibold ${
                            isMatchedVariant
                              ? 'text-slate-950'
                              : 'text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          {variant.label}
                        </span>
                        <span
                          className={`text-sm sm:text-base font-extrabold ${
                            isMatchedVariant
                              ? 'text-slate-950'
                              : 'text-slate-900 dark:text-white'
                          }`}
                        >
                          {formatPrice(variant.price, settings.currencySymbol)}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {!activeCardMatch && uncertainMatches.length > 0 && (
            <div className="pointer-events-auto w-full max-w-2xl animate-slide-up">
              <div className="flex items-center justify-between px-1 mb-2">
                <span className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-amber-300 drop-shadow">
                  <Sparkles className="h-3.5 w-3.5" />
                  Closest Matches — Tap to Inspect
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {uncertainMatches.map((item) => (
                  <button
                    key={item.product.id}
                    type="button"
                    onClick={() => setPinnedFallback(item)}
                    className="flex items-center gap-3 p-3 rounded-2xl bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border border-white/20 dark:border-slate-700 text-left shadow-xl hover:border-emerald-400 transition-all active:scale-[0.98]"
                  >
                    {item.product.angles[0]?.thumbnail && (
                      <img
                        src={item.product.angles[0].thumbnail}
                        alt={item.product.name}
                        className="h-12 w-12 rounded-xl object-cover shrink-0 bg-slate-200 dark:bg-slate-800"
                      />
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                        {item.product.name}
                      </p>
                      <p className="text-lg font-black text-emerald-600 dark:text-emerald-400 leading-tight mt-0.5">
                        {formatPrice(item.product.basePrice, settings.currencySymbol)}
                      </p>
                      <span className="text-[11px] font-semibold text-amber-600 dark:text-amber-400">
                        {Math.round(item.score * 100)}% match
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {!activeCardMatch && uncertainMatches.length === 0 && (
            <div className="px-4 py-2.5 rounded-full bg-slate-950/75 backdrop-blur-md border border-white/15 text-slate-200 text-xs sm:text-sm font-semibold shadow-lg">
              {isPaused
                ? 'Live scanning paused'
                : 'Center a registered item inside the brackets'}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
