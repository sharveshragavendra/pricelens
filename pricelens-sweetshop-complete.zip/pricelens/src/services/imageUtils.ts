/**
 * Client-side image compression, strict viewfinder center-cropping, and price formatting utilities.
 */

export async function compressImageFile(
  file: File,
  maxDimension = 320,
  quality = 0.78
): Promise<string> {
  const dataUrl = await readFileAsDataUrl(file);
  return compressDataUrl(dataUrl, maxDimension, quality);
}

export function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Failed to read image file.'));
      }
    };
    reader.onerror = () => reject(new Error('Unable to read image file.'));
    reader.readAsDataURL(file);
  });
}

export async function compressDataUrl(
  dataUrl: string,
  maxDimension = 320,
  quality = 0.78
): Promise<string> {
  const img = await loadImageElement(dataUrl);
  const { width, height } = fitDimensions(img.naturalWidth, img.naturalHeight, maxDimension);

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Canvas 2D context is unavailable.');
  }

  ctx.drawImage(img, 0, 0, width, height);
  return canvas.toDataURL('image/jpeg', quality);
}

/**
 * Draws the centered 1:1 square region inside the camera viewfinder onto a target canvas.
 * Eliminates widescreen aspect distortion and ~70% of background desk/hand clutter.
 */
export function drawViewfinderSquareCrop(
  video: HTMLVideoElement,
  canvas: HTMLCanvasElement,
  targetSize = 224,
  cropRatio = 0.66
): boolean {
  const vw = video.videoWidth;
  const vh = video.videoHeight;
  if (!vw || !vh || video.readyState < 2) return false;

  const side = Math.max(1, Math.round(Math.min(vw, vh) * cropRatio));
  const sx = Math.round((vw - side) / 2);
  const sy = Math.round((vh - side) / 2);

  if (canvas.width !== targetSize) canvas.width = targetSize;
  if (canvas.height !== targetSize) canvas.height = targetSize;

  const ctx = canvas.getContext('2d');
  if (!ctx) return false;

  ctx.drawImage(video, sx, sy, side, side, 0, 0, targetSize, targetSize);
  return true;
}

/**
 * Captures the centered viewfinder square from a live video stream as a compact JPEG data URL.
 * Used identically by Quick-Capture registration and Tier 2 Cloud Vision Smart Scan.
 */
export function captureVideoFrameAsDataUrl(
  video: HTMLVideoElement,
  targetSize = 384,
  quality = 0.84,
  cropRatio = 0.68
): string {
  const canvas = document.createElement('canvas');
  const ok = drawViewfinderSquareCrop(video, canvas, targetSize, cropRatio);
  if (!ok) {
    const vw = video.videoWidth || 640;
    const vh = video.videoHeight || 480;
    const { width, height } = fitDimensions(vw, vh, targetSize);
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas 2D context is unavailable.');
    ctx.drawImage(video, 0, 0, width, height);
  }
  return canvas.toDataURL('image/jpeg', quality);
}

export function loadImageElement(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Failed to load image for AI processing.'));
    img.src = src;
  });
}

function fitDimensions(
  width: number,
  height: number,
  maxDimension: number
): { width: number; height: number } {
  if (width <= maxDimension && height <= maxDimension) {
    return { width: Math.max(1, width), height: Math.max(1, height) };
  }
  const scale = maxDimension / Math.max(width, height);
  return {
    width: Math.max(1, Math.round(width * scale)),
    height: Math.max(1, Math.round(height * scale)),
  };
}

export function dataUrlToBlob(dataUrl: string): Blob {
  const [meta, base64] = dataUrl.split(',');
  const mimeMatch = /data:(.*?);base64/.exec(meta);
  const mime = mimeMatch ? mimeMatch[1] : 'image/jpeg';
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) {
    bytes[i] = binary.charCodeAt(i);
  }
  return new Blob([bytes], { type: mime });
}

export function formatPrice(amount: number, currencySymbol: string): string {
  const formatted = Number.isInteger(amount)
    ? amount.toLocaleString('en-IN')
    : amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return `${currencySymbol}${formatted}`;
}
