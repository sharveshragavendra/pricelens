import type { Product } from '../types';

export interface WeightPriceCalculation {
  isWeightBased: boolean;
  totalPrice: number;
  rateLabel: string;
  formulaText: string;
  weightKg: number;
  weightGrams: number;
}

/**
 * Parses a product's unit string to determine its reference weight in kilograms.
 * Supports sweet-shop pricing units such as:
 *   - "per kg" / "kg" / "1 kg" -> 1.0 kg
 *   - "per 500g" / "500g" / "half kg" -> 0.5 kg
 *   - "per 250g" / "250g" -> 0.25 kg
 *   - "per 100g" / "100g" -> 0.1 kg
 *   - "per g" / "gram" -> 0.001 kg
 * Returns null for non-weight units like "per piece", "per box", "per pack".
 */
export function parseUnitReferenceKg(unit: string): number | null {
  const normalized = unit.trim().toLowerCase();
  if (!normalized) return 1.0; // Default to per-kg in sweet shop scale mode if blank

  if (/\b(piece|pcs|pc|box|pack|packet|bottle|cup|plate|tray|dozen)\b/.test(normalized)) {
    return null;
  }

  if (normalized.includes('half kg') || normalized.includes('1/2 kg')) {
    return 0.5;
  }

  const kgMatch = /(\d+(?:\.\d+)?)\s*k(?:g|ilo)/i.exec(normalized);
  if (kgMatch) {
    const val = Number.parseFloat(kgMatch[1]);
    return Number.isFinite(val) && val > 0 ? val : 1.0;
  }

  if (/\bkg\b|\bkilo\b/.test(normalized)) {
    return 1.0;
  }

  const gramMatch = /(\d+(?:\.\d+)?)\s*(?:g|gm|gms|gram|grams)\b/i.exec(normalized);
  if (gramMatch) {
    const grams = Number.parseFloat(gramMatch[1]);
    return Number.isFinite(grams) && grams > 0 ? grams / 1000 : null;
  }

  if (/\b(?:g|gm|gram|grams)\b/.test(normalized)) {
    return 0.001;
  }

  return 1.0;
}

/**
 * Calculates the exact counter price for a weighed sweet/product.
 */
export function calculateWeighedPrice(
  product: Product,
  weightKg: number,
  currencySymbol: string
): WeightPriceCalculation {
  const safeWeightKg = Math.max(0, Number.isFinite(weightKg) ? weightKg : 0);
  const weightGrams = Math.round(safeWeightKg * 1000);
  const refKg = parseUnitReferenceKg(product.unit);

  if (refKg === null) {
    // Non-weight item (e.g. per piece / per box) — show base price cleanly
    return {
      isWeightBased: false,
      totalPrice: product.basePrice,
      rateLabel: `${currencySymbol}${product.basePrice} / ${product.unit.replace(/^per\s+/i, '')}`,
      formulaText: `Fixed unit price (${product.unit || 'per item'})`,
      weightKg: safeWeightKg,
      weightGrams,
    };
  }

  const pricePerKg = product.basePrice / refKg;
  const rawTotal = pricePerKg * safeWeightKg;
  const roundedTotal = Math.round(rawTotal * 100) / 100;

  const rateLabel =
    refKg === 1
      ? `${currencySymbol}${formatCompactNum(product.basePrice)} / kg`
      : `${currencySymbol}${formatCompactNum(product.basePrice)} / ${Math.round(refKg * 1000)}g`;

  const displayWeight =
    safeWeightKg >= 1
      ? `${safeWeightKg.toFixed(3)} kg`
      : `${weightGrams} g (${safeWeightKg.toFixed(3)} kg)`;

  const formulaText = `${displayWeight} × ${currencySymbol}${formatCompactNum(pricePerKg)}/kg`;

  return {
    isWeightBased: true,
    totalPrice: roundedTotal,
    rateLabel,
    formulaText,
    weightKg: safeWeightKg,
    weightGrams,
  };
}

export function formatWeightDisplay(weightKg: number): string {
  if (!Number.isFinite(weightKg) || weightKg <= 0) return '0 g';
  if (weightKg < 1) {
    return `${Math.round(weightKg * 1000)} g`;
  }
  return `${weightKg.toFixed(3)} kg`;
}

function formatCompactNum(n: number): string {
  return Number.isInteger(n)
    ? n.toLocaleString('en-IN')
    : n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
