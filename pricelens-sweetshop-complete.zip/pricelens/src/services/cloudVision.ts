import type {
  CloudAiProvider,
  CloudVisionStatus,
  Product,
  ScaleWeightReading,
} from '../types';

export interface CloudIdentifyResponse {
  matchedProductId: string | null;
  matchedVariantId: string | null;
  confidence: number;
  reason: string;
  provider: CloudAiProvider;
  model: string;
}

export interface ScaleOcrResponse extends ScaleWeightReading {
  provider: CloudAiProvider;
  model: string;
}

export interface SweetScaleCombinedResponse {
  matchedProductId: string | null;
  matchedVariantId: string | null;
  productConfidence: number;
  productReason: string;
  weightKg: number | null;
  rawDisplayText: string;
  detectedUnit: 'kg' | 'g' | 'unknown';
  weightConfidence: number;
  weightReason: string;
  provider: CloudAiProvider;
  model: string;
}

const DEFAULT_STATUS: CloudVisionStatus = {
  available: false,
  openrouterConfigured: false,
  geminiConfigured: false,
  claudeConfigured: false,
  openrouterModel: 'google/gemma-4-31b-it:free',
  geminiModel: 'gemini-3.5-flash-lite',
  claudeModel: 'claude-haiku-5-5',
};

export async function fetchCloudVisionStatus(): Promise<CloudVisionStatus> {
  try {
    const resp = await fetch('/api/identify', { method: 'GET' });
    if (!resp.ok) return DEFAULT_STATUS;
    const data = (await resp.json()) as Partial<CloudVisionStatus>;
    return {
      available: Boolean(data.available),
      openrouterConfigured: Boolean(data.openrouterConfigured),
      geminiConfigured: Boolean(data.geminiConfigured),
      claudeConfigured: Boolean(data.claudeConfigured),
      openrouterModel: data.openrouterModel || DEFAULT_STATUS.openrouterModel,
      geminiModel: data.geminiModel || DEFAULT_STATUS.geminiModel,
      claudeModel: data.claudeModel || DEFAULT_STATUS.claudeModel,
    };
  } catch {
    return DEFAULT_STATUS;
  }
}

async function postIdentify<T>(payload: Record<string, unknown>, timeoutMs = 18000): Promise<T> {
  const controller = new AbortController();
  const timeoutId = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    const resp = await fetch('/api/identify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: controller.signal,
      body: JSON.stringify(payload),
    });
    const data = (await resp.json().catch(() => ({}))) as T & { error?: string };
    if (!resp.ok) {
      throw new Error(
        data.error ||
          `Cloud Vision API returned ${resp.status}. Verify your API key in Vercel Environment Variables.`
      );
    }
    return data;
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') {
      throw new Error('Cloud AI request timed out. Try again with a steady frame.');
    }
    throw err;
  } finally {
    window.clearTimeout(timeoutId);
  }
}

export async function identifyWithCloudAI(params: {
  imageBase64: string;
  provider: CloudAiProvider;
  candidates: Product[];
}): Promise<CloudIdentifyResponse> {
  return postIdentify<CloudIdentifyResponse>({
    mode: 'identify',
    imageBase64: params.imageBase64,
    provider: params.provider,
    candidates: params.candidates.slice(0, 10).map((p) => ({
      id: p.id,
      name: p.name,
      category: p.category,
      unit: p.unit,
      variants: p.variants,
    })),
  });
}

export async function readScaleWeightWithCloudAI(params: {
  scaleImageBase64: string;
  provider: CloudAiProvider;
  scaleDefaultUnit: 'kg' | 'g';
}): Promise<ScaleOcrResponse> {
  return postIdentify<ScaleOcrResponse>({
    mode: 'scale_ocr',
    imageBase64: params.scaleImageBase64,
    provider: params.provider,
    scaleDefaultUnit: params.scaleDefaultUnit,
  });
}

export async function analyzeSweetAndScaleWithCloudAI(params: {
  productImageBase64: string;
  scaleImageBase64: string;
  provider: CloudAiProvider;
  scaleDefaultUnit: 'kg' | 'g';
  candidates: Product[];
}): Promise<SweetScaleCombinedResponse> {
  return postIdentify<SweetScaleCombinedResponse>({
    mode: 'sweet_scale_combined',
    productImageBase64: params.productImageBase64,
    scaleImageBase64: params.scaleImageBase64,
    provider: params.provider,
    scaleDefaultUnit: params.scaleDefaultUnit,
    candidates: params.candidates.slice(0, 10).map((p) => ({
      id: p.id,
      name: p.name,
      category: p.category,
      unit: p.unit,
      variants: p.variants,
    })),
  });
}
