import * as tf from '@tensorflow/tfjs';
import * as mobilenet from '@tensorflow-models/mobilenet';
import { MIN_TOP_MARGIN, type FrameQualityResult, type Product, type ProductMatch } from '../types';
import { drawViewfinderSquareCrop } from './imageUtils';

/**
 * PriceLens Tier 1 Vision Engine
 * - 100% client-side MobileNet v2 (alpha 1.0)
 * - Strict 224x224 viewfinder center-crop + dual-scale live extraction (tight 62% & medium 84%)
 * - Blended max-angle + L2-normalized centroid scoring
 * - Top-1 vs Top-2 margin check to prevent ambiguous false locks
 * - 3-frame temporal smoothing buffer + hidden-canvas lighting/stability analyzer
 */

let cachedModel: mobilenet.MobileNet | null = null;
let loadingPromise: Promise<mobilenet.MobileNet> | null = null;

export async function loadVisionModel(
  onProgress?: (percent: number, stage: string) => void
): Promise<mobilenet.MobileNet> {
  if (cachedModel) {
    onProgress?.(100, 'AI Ready');
    return cachedModel;
  }

  if (!loadingPromise) {
    loadingPromise = (async () => {
      onProgress?.(15, 'Initializing TensorFlow.js...');
      await tf.ready();

      onProgress?.(45, 'Loading MobileNet v2...');
      const model = await mobilenet.load({
        version: 2,
        alpha: 1.0,
      });

      onProgress?.(85, 'Warming up vision engine...');
      tf.tidy(() => {
        const dummy = tf.zeros([1, 224, 224, 3]);
        model.infer(dummy, true);
      });

      cachedModel = model;
      onProgress?.(100, 'AI Ready');
      return model;
    })().catch((err) => {
      loadingPromise = null;
      throw err;
    });
  }

  return loadingPromise;
}

export function isModelLoaded(): boolean {
  return cachedModel !== null;
}

/**
 * Extracts an L2-normalized feature embedding from an image, video, or canvas element.
 * Uses tf.tidy() to dispose all intermediate WebGL tensors immediately.
 */
export function extractNormalizedEmbedding(
  input: HTMLImageElement | HTMLVideoElement | HTMLCanvasElement
): number[] {
  if (!cachedModel) {
    throw new Error('AI Vision Model is not loaded yet.');
  }

  const rawArray = tf.tidy(() => {
    const activation = cachedModel!.infer(input, true) as tf.Tensor;
    const flat = activation.flatten();
    const norm = tf.norm(flat);
    const safeNorm = tf.maximum(norm, tf.scalar(1e-8));
    const normalized = flat.div(safeNorm);
    return normalized.dataSync();
  });

  const embedding = new Array<number>(rawArray.length);
  for (let i = 0; i < rawArray.length; i += 1) {
    embedding[i] = Math.round(rawArray[i] * 100000) / 100000;
  }
  return embedding;
}

/**
 * Dot product of two L2-normalized vectors equals their cosine similarity.
 */
export function cosineSimilarity(a: number[], b: number[]): number {
  const len = Math.min(a.length, b.length);
  if (len === 0) return 0;

  let dot = 0;
  for (let i = 0; i < len; i += 1) {
    dot += a[i] * b[i];
  }

  return Math.max(0, Math.min(1, dot));
}

function computeNormalizedCentroid(embeddings: number[][]): number[] | null {
  if (embeddings.length < 2) return null;
  const dim = embeddings[0].length;
  if (dim === 0) return null;

  const mean = new Array<number>(dim).fill(0);
  for (const vec of embeddings) {
    for (let i = 0; i < dim; i += 1) {
      mean[i] += vec[i] ?? 0;
    }
  }

  let normSq = 0;
  for (let i = 0; i < dim; i += 1) {
    mean[i] /= embeddings.length;
    normSq += mean[i] * mean[i];
  }

  const norm = Math.sqrt(normSq);
  if (norm < 1e-8) return null;

  for (let i = 0; i < dim; i += 1) {
    mean[i] /= norm;
  }
  return mean;
}

/**
 * Matches one or more live crop embeddings (tight + medium viewfinder crops)
 * against all stored products using blended best-angle (75%) + centroid (25%) scoring.
 */
export function matchProductsMultiCrop(
  frameEmbeddings: number[][],
  products: Product[]
): {
  ranked: ProductMatch[];
  topMargin: number;
  hasClearLead: boolean;
} {
  const results: ProductMatch[] = [];

  for (const product of products) {
    if (!product.angles || product.angles.length === 0) continue;

    const validAngles = product.angles.filter(
      (a) => Array.isArray(a.embedding) && a.embedding.length > 0
    );
    if (validAngles.length === 0) continue;

    const centroid = computeNormalizedCentroid(validAngles.map((a) => a.embedding));

    let bestCombined = -1;
    let bestAngleId = validAngles[0].id;

    for (const frameEmb of frameEmbeddings) {
      let bestAngleScore = -1;
      let localBestAngleId = validAngles[0].id;

      for (const angle of validAngles) {
        const s = cosineSimilarity(frameEmb, angle.embedding);
        if (s > bestAngleScore) {
          bestAngleScore = s;
          localBestAngleId = angle.id;
        }
      }

      const combined = centroid
        ? 0.75 * bestAngleScore + 0.25 * cosineSimilarity(frameEmb, centroid)
        : bestAngleScore;

      if (combined > bestCombined) {
        bestCombined = combined;
        bestAngleId = localBestAngleId;
      }
    }

    if (bestCombined >= 0) {
      results.push({
        product,
        score: Math.max(0, Math.min(1, bestCombined)),
        bestAngleId,
        source: 'local',
      });
    }
  }

  results.sort((a, b) => b.score - a.score);

  const topMargin =
    results.length >= 2 ? results[0].score - results[1].score : 1;
  const hasClearLead = results.length < 2 || topMargin >= MIN_TOP_MARGIN;

  return { ranked: results, topMargin, hasClearLead };
}

/**
 * Extracts dual-scale (tight 62% & medium 84%) center-cropped 224x224 embeddings from a live video frame.
 */
export function extractDualScaleViewfinderEmbeddings(
  video: HTMLVideoElement,
  cropCanvas: HTMLCanvasElement
): number[][] {
  const embeddings: number[][] = [];

  if (drawViewfinderSquareCrop(video, cropCanvas, 224, 0.62)) {
    embeddings.push(extractNormalizedEmbedding(cropCanvas));
  }
  if (drawViewfinderSquareCrop(video, cropCanvas, 224, 0.84)) {
    embeddings.push(extractNormalizedEmbedding(cropCanvas));
  }

  return embeddings;
}

/**
 * 3-frame temporal smoothing buffer to eliminate price display flicker.
 */
interface FrameVote {
  productId: string | null;
  score: number;
}

export class TemporalSmoother {
  private readonly windowSize: number;
  private buffer: FrameVote[] = [];

  constructor(windowSize = 3) {
    this.windowSize = windowSize;
  }

  reset(): void {
    this.buffer = [];
  }

  push(topMatch: ProductMatch | null, minTrackScore = 0.55): {
    stableProductId: string | null;
    smoothedScore: number;
    consistentFrames: number;
  } {
    const vote: FrameVote =
      topMatch && topMatch.score >= minTrackScore
        ? { productId: topMatch.product.id, score: topMatch.score }
        : { productId: null, score: topMatch?.score ?? 0 };

    this.buffer.push(vote);
    if (this.buffer.length > this.windowSize) {
      this.buffer.shift();
    }

    const counts = new Map<string, { count: number; totalScore: number }>();
    for (const item of this.buffer) {
      if (!item.productId) continue;
      const entry = counts.get(item.productId) ?? { count: 0, totalScore: 0 };
      entry.count += 1;
      entry.totalScore += item.score;
      counts.set(item.productId, entry);
    }

    let winnerId: string | null = null;
    let winnerCount = 0;
    let winnerAvg = 0;

    counts.forEach((stats, productId) => {
      const avg = stats.totalScore / stats.count;
      if (stats.count > winnerCount || (stats.count === winnerCount && avg > winnerAvg)) {
        winnerId = productId;
        winnerCount = stats.count;
        winnerAvg = avg;
      }
    });

    if (winnerId && winnerCount >= 2) {
      return {
        stableProductId: winnerId,
        smoothedScore: winnerAvg,
        consistentFrames: winnerCount,
      };
    }

    return {
      stableProductId: null,
      smoothedScore: topMatch?.score ?? 0,
      consistentFrames: winnerCount,
    };
  }
}

/**
 * Analyzes frame brightness and frame-to-frame motion on a tiny 64x48 hidden canvas.
 * Flags "Too dark" or "Hold steady" with minimal CPU overhead.
 */
export function analyzeFrameQuality(
  video: HTMLVideoElement,
  canvas: HTMLCanvasElement,
  prevGray: Uint8ClampedArray | null
): { quality: FrameQualityResult; nextGray: Uint8ClampedArray } {
  const width = 64;
  const height = 48;
  if (canvas.width !== width) canvas.width = width;
  if (canvas.height !== height) canvas.height = height;

  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  const pixelCount = width * height;
  const gray = new Uint8ClampedArray(pixelCount);

  if (!ctx || video.readyState < 2) {
    return {
      quality: { status: 'good', label: null, brightness: 128, motion: 0 },
      nextGray: gray,
    };
  }

  ctx.drawImage(video, 0, 0, width, height);
  const { data } = ctx.getImageData(0, 0, width, height);

  let luminanceSum = 0;
  let motionDiffSum = 0;

  for (let i = 0, p = 0; i < data.length; i += 4, p += 1) {
    const lum = Math.round(0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]);
    gray[p] = lum;
    luminanceSum += lum;
    if (prevGray) {
      motionDiffSum += Math.abs(lum - prevGray[p]);
    }
  }

  const brightness = luminanceSum / pixelCount;
  const motion = prevGray ? motionDiffSum / pixelCount : 0;

  if (brightness < 44) {
    return {
      quality: { status: 'too_dark', label: 'Too dark', brightness, motion },
      nextGray: gray,
    };
  }

  if (prevGray && motion > 26) {
    return {
      quality: { status: 'hold_steady', label: 'Hold steady', brightness, motion },
      nextGray: gray,
    };
  }

  return {
    quality: { status: 'good', label: null, brightness, motion },
    nextGray: gray,
  };
}
