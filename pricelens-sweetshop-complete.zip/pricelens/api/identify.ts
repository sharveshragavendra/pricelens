/**
 * Vercel Serverless Function: POST /api/identify & GET /api/identify
 * Supports 3 modes:
 *   1. mode = 'identify' (default): Identifies a product from 1 image + Top-10 candidates
 *   2. mode = 'scale_ocr': Reads the numeric weight on a digital weighing scale LCD/LED display (CAM2)
 *   3. mode = 'sweet_scale_combined': Reads BOTH the sweet/product (CAM1) AND scale weight (CAM2) in 1 call
 *
 * Providers:
 *   - Gemini (default: gemini-3.5-flash-lite) via GEMINI_API_KEY
 *   - OpenRouter (default: google/gemma-4-31b-it:free) via OPENROUTER_API_KEY
 *   - Claude (default: claude-haiku-5-5) via ANTHROPIC_API_KEY
 */

interface ApiRequest {
  method?: string;
  body?: unknown;
}

interface ApiResponse {
  status: (code: number) => ApiResponse;
  json: (payload: unknown) => void;
  setHeader: (name: string, value: string) => void;
}

interface CandidateVariant {
  id: string;
  label: string;
  price: number;
}

interface CandidateProduct {
  id: string;
  name: string;
  category?: string;
  unit?: string;
  variants?: CandidateVariant[];
}

type ProviderId = 'openrouter' | 'gemini' | 'claude';
type IdentifyMode = 'identify' | 'scale_ocr' | 'sweet_scale_combined';

interface IdentifyRequestBody {
  mode?: IdentifyMode;
  provider?: ProviderId;
  imageBase64?: string;        // Used in 'identify' or 'scale_ocr'
  productImageBase64?: string; // CAM1 (Front - Sweet on pan) for 'sweet_scale_combined'
  scaleImageBase64?: string;   // CAM2 (Back - Scale display) for 'sweet_scale_combined'
  scaleDefaultUnit?: 'kg' | 'g';
  candidates?: CandidateProduct[];
}

interface NormalizedImage {
  mimeType: string;
  base64: string;
  fullDataUrl: string;
}

const DEFAULT_OPENROUTER_MODEL =
  process.env.OPENROUTER_MODEL || 'google/gemma-4-31b-it:free';
const DEFAULT_GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-3.5-flash-lite';
const DEFAULT_CLAUDE_MODEL = process.env.CLAUDE_MODEL || 'claude-haiku-5-5';

function normalizeImage(dataUrl: string): NormalizedImage {
  const trimmed = dataUrl.trim();
  const match = /^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/.exec(trimmed);
  if (match) {
    return { mimeType: match[1], base64: match[2], fullDataUrl: trimmed };
  }
  return {
    mimeType: 'image/jpeg',
    base64: trimmed,
    fullDataUrl: `data:image/jpeg;base64,${trimmed}`,
  };
}

function buildCandidatesJson(candidates: CandidateProduct[]): string {
  return JSON.stringify(
    candidates.slice(0, 12).map((c) => ({
      id: c.id,
      name: c.name,
      ...(c.category ? { category: c.category } : {}),
      ...(c.unit ? { unit: c.unit } : {}),
      ...(c.variants && c.variants.length > 0
        ? { variants: c.variants.map((v) => ({ id: v.id, label: v.label })) }
        : {}),
    }))
  );
}

function buildIdentifyPrompt(candidates: CandidateProduct[]): string {
  return [
    'You are a retail counter visual product identifier (including Indian sweets, snacks, and packaged goods).',
    'Inspect the product in the photo (color, texture, shape, garnish, brand text, flavor, and pack size).',
    'Match it ONLY to one product from the candidate catalog below. If none clearly matches, return null.',
    `CANDIDATES: ${buildCandidatesJson(candidates)}`,
    'Return ONLY valid JSON with this exact schema:',
    '{"matchedProductId": string | null, "matchedVariantId": string | null, "confidence": number_between_0_and_1, "reason": "short 4-8 word explanation"}',
  ].join('\n');
}

function buildScaleOcrPrompt(defaultUnit: 'kg' | 'g'): string {
  return [
    'You are a precision digital weighing scale OCR reader at a retail sweet shop counter.',
    'Read the exact weight displayed on the 7-segment LED/LCD screen in this photo.',
    `If no unit label is visible on the scale display, assume the scale reads in ${defaultUnit}.`,
    'Always convert the final weight into kilograms (weightKg) as a decimal number (for example: 250g -> 0.250, 0.350 kg -> 0.350, 1.250 kg -> 1.250).',
    'If the display is unreadable, blank, or shows 0, return weightKg: null.',
    'Return ONLY valid JSON with this exact schema:',
    '{"weightKg": number | null, "rawDisplayText": string, "detectedUnit": "kg" | "g" | "unknown", "confidence": number_between_0_and_1, "reason": "short 4-8 word note"}',
  ].join('\n');
}

function buildCombinedPrompt(candidates: CandidateProduct[], defaultUnit: 'kg' | 'g'): string {
  return [
    'You are an AI counter assistant at a sweet shop with two synchronized camera photos:',
    '- IMAGE 1 (Front Camera): The sweet or product placed on the weighing pan.',
    '- IMAGE 2 (Back Camera): The digital weighing scale LCD/LED display showing the exact weight.',
    'Tasks:',
    '1. Match IMAGE 1 to the closest product from CANDIDATES (or null if none matches).',
    `2. Read the exact numeric weight on IMAGE 2 and convert it to kilograms (weightKg). If no unit is visible on the scale, assume ${defaultUnit}.`,
    `CANDIDATES: ${buildCandidatesJson(candidates)}`,
    'Return ONLY valid JSON with this exact schema:',
    '{"matchedProductId": string | null, "matchedVariantId": string | null, "productConfidence": number_between_0_and_1, "productReason": "short note", "weightKg": number | null, "rawDisplayText": string, "detectedUnit": "kg" | "g" | "unknown", "weightConfidence": number_between_0_and_1, "weightReason": "short note"}',
  ].join('\n');
}

function extractJsonObject(rawText: string): Record<string, unknown> {
  const cleaned = rawText
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/\s*```$/i, '')
    .trim();
  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  const slice = start >= 0 && end > start ? cleaned.slice(start, end + 1) : cleaned;
  return JSON.parse(slice) as Record<string, unknown>;
}

async function callGemini(
  images: NormalizedImage[],
  prompt: string
): Promise<{ text: string; model: string }> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured in Vercel Environment Variables.');
  }
  const model = DEFAULT_GEMINI_MODEL;
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;

  const parts: Array<Record<string, unknown>> = [{ text: prompt }];
  for (const img of images) {
    parts.push({ inlineData: { mimeType: img.mimeType, data: img.base64 } });
  }

  const makePayload = (includeThinkingConfig: boolean) => ({
    contents: [{ role: 'user', parts }],
    generationConfig: {
      responseMimeType: 'application/json',
      maxOutputTokens: 220,
      ...(includeThinkingConfig ? { thinkingConfig: { thinkingLevel: 'minimal' } } : {}),
    },
  });

  let resp = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-goog-api-key': apiKey,
    },
    body: JSON.stringify(makePayload(true)),
  });

  if (!resp.ok && resp.status === 400) {
    resp = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': apiKey,
      },
      body: JSON.stringify(makePayload(false)),
    });
  }

  if (!resp.ok) {
    const errText = await resp.text().catch(() => '');
    throw new Error(`Gemini API error (${resp.status}): ${errText.slice(0, 220)}`);
  }

  const data = (await resp.json()) as {
    candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
  };
  const text = data.candidates?.[0]?.content?.parts?.map((p) => p.text ?? '').join('') ?? '';
  if (!text) throw new Error('Gemini returned an empty response.');
  return { text, model };
}

async function callOpenRouter(
  images: NormalizedImage[],
  prompt: string
): Promise<{ text: string; model: string }> {
  const apiKey = process.env.OPENROUTER_API_KEY;
  if (!apiKey) {
    throw new Error('OPENROUTER_API_KEY is not configured in Vercel Environment Variables.');
  }
  const model = DEFAULT_OPENROUTER_MODEL;

  const content: Array<Record<string, unknown>> = [{ type: 'text', text: prompt }];
  for (const img of images) {
    content.push({ type: 'image_url', image_url: { url: img.fullDataUrl } });
  }

  const resp = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
      'HTTP-Referer': 'https://pricelens-firebase-app.vercel.app',
      'X-Title': 'PriceLens',
    },
    body: JSON.stringify({
      model,
      max_tokens: 220,
      temperature: 0.1,
      messages: [{ role: 'user', content }],
    }),
  });

  if (!resp.ok) {
    const errText = await resp.text().catch(() => '');
    throw new Error(`OpenRouter API error (${resp.status}): ${errText.slice(0, 220)}`);
  }

  const data = (await resp.json()) as {
    choices?: Array<{
      message?: { content?: string | Array<{ type?: string; text?: string }> };
    }>;
  };
  const raw = data.choices?.[0]?.message?.content;
  const text =
    typeof raw === 'string'
      ? raw
      : Array.isArray(raw)
        ? raw.map((p) => p.text ?? '').join('')
        : '';
  if (!text) throw new Error('OpenRouter returned an empty response.');
  return { text, model };
}

async function callClaude(
  images: NormalizedImage[],
  prompt: string
): Promise<{ text: string; model: string }> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    throw new Error('ANTHROPIC_API_KEY is not configured in Vercel Environment Variables.');
  }
  const model = DEFAULT_CLAUDE_MODEL;

  const content: Array<Record<string, unknown>> = [];
  for (const img of images) {
    const mediaType =
      img.mimeType === 'image/png' || img.mimeType === 'image/webp' || img.mimeType === 'image/gif'
        ? img.mimeType
        : 'image/jpeg';
    content.push({
      type: 'image',
      source: { type: 'base64', media_type: mediaType, data: img.base64 },
    });
  }
  content.push({ type: 'text', text: prompt });

  const resp = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model,
      max_tokens: 220,
      messages: [{ role: 'user', content }],
    }),
  });

  if (!resp.ok) {
    const errText = await resp.text().catch(() => '');
    throw new Error(`Claude API error (${resp.status}): ${errText.slice(0, 220)}`);
  }

  const data = (await resp.json()) as {
    content?: Array<{ type?: string; text?: string }>;
  };
  const text =
    data.content
      ?.filter((b) => b.type === 'text')
      .map((b) => b.text ?? '')
      .join('') ?? '';
  if (!text) throw new Error('Claude returned an empty response.');
  return { text, model };
}

async function runProvider(
  provider: ProviderId,
  images: NormalizedImage[],
  prompt: string
): Promise<{ text: string; model: string; provider: ProviderId }> {
  if (provider === 'openrouter') {
    const out = await callOpenRouter(images, prompt);
    return { ...out, provider };
  }
  if (provider === 'claude') {
    const out = await callClaude(images, prompt);
    return { ...out, provider };
  }
  const out = await callGemini(images, prompt);
  return { ...out, provider: 'gemini' };
}

function clampScore(v: unknown): number {
  return typeof v === 'number' && Number.isFinite(v) ? Math.max(0, Math.min(1, v)) : 0;
}

function parseWeightKg(v: unknown): number | null {
  if (typeof v === 'number' && Number.isFinite(v) && v > 0 && v < 500) {
    return Math.round(v * 1000) / 1000;
  }
  if (typeof v === 'string') {
    const n = Number.parseFloat(v);
    if (Number.isFinite(n) && n > 0 && n < 500) {
      return Math.round(n * 1000) / 1000;
    }
  }
  return null;
}

export default async function handler(req: ApiRequest, res: ApiResponse): Promise<void> {
  res.setHeader('Cache-Control', 'no-store');

  if (req.method === 'GET') {
    res.status(200).json({
      available: true,
      openrouterConfigured: Boolean(process.env.OPENROUTER_API_KEY),
      geminiConfigured: Boolean(process.env.GEMINI_API_KEY),
      claudeConfigured: Boolean(process.env.ANTHROPIC_API_KEY),
      openrouterModel: DEFAULT_OPENROUTER_MODEL,
      geminiModel: DEFAULT_GEMINI_MODEL,
      claudeModel: DEFAULT_CLAUDE_MODEL,
    });
    return;
  }

  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed. Use GET or POST.' });
    return;
  }

  try {
    const body = (typeof req.body === 'string' ? JSON.parse(req.body) : req.body) as
      | IdentifyRequestBody
      | undefined;

    const mode: IdentifyMode = body?.mode || 'identify';
    const provider: ProviderId =
      body?.provider === 'openrouter'
        ? 'openrouter'
        : body?.provider === 'claude'
          ? 'claude'
          : 'gemini';
    const defaultUnit: 'kg' | 'g' = body?.scaleDefaultUnit === 'g' ? 'g' : 'kg';

    // Mode 1: Scale Display OCR only (CAM2)
    if (mode === 'scale_ocr') {
      if (!body?.imageBase64) {
        res.status(400).json({ error: 'Missing scale display imageBase64.' });
        return;
      }
      const { text, model } = await runProvider(
        provider,
        [normalizeImage(body.imageBase64)],
        buildScaleOcrPrompt(defaultUnit)
      );
      const parsed = extractJsonObject(text);
      res.status(200).json({
        weightKg: parseWeightKg(parsed.weightKg),
        rawDisplayText: typeof parsed.rawDisplayText === 'string' ? parsed.rawDisplayText : '',
        detectedUnit:
          parsed.detectedUnit === 'kg' || parsed.detectedUnit === 'g'
            ? parsed.detectedUnit
            : 'unknown',
        confidence: clampScore(parsed.confidence),
        reason: typeof parsed.reason === 'string' ? parsed.reason : 'Scale display read',
        provider,
        model,
      });
      return;
    }

    // Mode 2: Combined Sweet (CAM1) + Weighing Scale Display (CAM2) in 1 call
    if (mode === 'sweet_scale_combined') {
      if (!body?.productImageBase64 || !body?.scaleImageBase64) {
        res.status(400).json({ error: 'Both productImageBase64 and scaleImageBase64 are required.' });
        return;
      }
      const candidates = Array.isArray(body.candidates) ? body.candidates : [];
      const { text, model } = await runProvider(
        provider,
        [normalizeImage(body.productImageBase64), normalizeImage(body.scaleImageBase64)],
        buildCombinedPrompt(candidates, defaultUnit)
      );
      const parsed = extractJsonObject(text);
      const validProduct = candidates.find((c) => c.id === parsed.matchedProductId);
      const validVariant = validProduct?.variants?.find(
        (v) => v.id === parsed.matchedVariantId
      );

      res.status(200).json({
        matchedProductId: validProduct ? validProduct.id : null,
        matchedVariantId: validVariant ? validVariant.id : null,
        productConfidence: clampScore(parsed.productConfidence),
        productReason:
          typeof parsed.productReason === 'string' ? parsed.productReason : 'Sweet identified',
        weightKg: parseWeightKg(parsed.weightKg),
        rawDisplayText: typeof parsed.rawDisplayText === 'string' ? parsed.rawDisplayText : '',
        detectedUnit:
          parsed.detectedUnit === 'kg' || parsed.detectedUnit === 'g'
            ? parsed.detectedUnit
            : 'unknown',
        weightConfidence: clampScore(parsed.weightConfidence),
        weightReason:
          typeof parsed.weightReason === 'string' ? parsed.weightReason : 'Scale reading',
        provider,
        model,
      });
      return;
    }

    // Mode 3: Standard single-product identification
    if (!body?.imageBase64) {
      res.status(400).json({ error: 'Missing imageBase64 payload.' });
      return;
    }
    const candidates = Array.isArray(body.candidates) ? body.candidates : [];
    if (candidates.length === 0) {
      res.status(400).json({ error: 'No candidate products provided.' });
      return;
    }

    const { text, model } = await runProvider(
      provider,
      [normalizeImage(body.imageBase64)],
      buildIdentifyPrompt(candidates)
    );
    const parsed = extractJsonObject(text);
    const validProduct = candidates.find((c) => c.id === parsed.matchedProductId);
    const validVariant = validProduct?.variants?.find(
      (v) => v.id === parsed.matchedVariantId
    );

    res.status(200).json({
      matchedProductId: validProduct ? validProduct.id : null,
      matchedVariantId: validVariant ? validVariant.id : null,
      confidence: clampScore(parsed.confidence),
      reason: typeof parsed.reason === 'string' ? parsed.reason : 'Visual match',
      provider,
      model,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Cloud vision request failed.';
    res.status(500).json({ error: message });
  }
}
